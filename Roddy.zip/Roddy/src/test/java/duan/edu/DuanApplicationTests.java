package duan.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuanApplicationTests {

	@Test
	void contextLoads() {
	}

}

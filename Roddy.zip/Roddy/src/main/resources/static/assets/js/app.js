const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});
var app = angular.module("app", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
        .when("/product", {
            templateUrl: "product.html",
            controller: "product-ctrl"
        })
        .when("/account", {
            templateUrl: "account.html",
            controller: "account-ctrl"
        })
        .when("/thuonghieu", {
            templateUrl: "thuonghieu.html",
            controller: "thuonghieu-ctrl"
        })
        .when("/loai", {
            templateUrl: "loai.html",
            controller: "loai-ctrl"
        })
        .when("/donhang", {
            templateUrl: "donhang.html",
            controller: "donhang-ctrl"
        })
        .when("/kho", {
            templateUrl: "kho.html",
            controller: "kho-ctrl"
        })
        .otherwise({
            templateUrl: "dashboard.html"
        });
})
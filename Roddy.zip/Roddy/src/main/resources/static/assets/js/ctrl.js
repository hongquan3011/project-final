const app = angular.module("app", []);
app.controller("ctrl", function($scope, $http) {
	$scope.items = [];
	$scope.products = [];
	$scope.count = 0;
	$scope.feelbacks = []
	$scope.voucherAll = [];
	$scope.accounts = {};
	$scope.voucherUsers = []; 
	$scope.initialize = function() {
		//load 
		$http.get(`/rest/carts`).then(resp => {
			$scope.items = resp.data
		})
		$http.get(`/rest/vouchers`).then(resp => {
			$scope.voucherAll = resp.data;
		})
		$http.get(`/rest/accounts/profile`).then(resp => {
			$scope.accounts = resp.data;
		})
		

	}
	$scope.voucherUser = function() {
		$http.get(`/rest/vouchers/http`).then(resp => {
			$scope.voucherUsers = resp.data;
		});

	}
	//khoi dau
	$scope.initialize();


	// cap nhat acc 
	$scope.update = function() {
		var item = angular.copy($scope.accounts);
		item.status = true;
		$http.put(`/rest/accounts/${item.id}`, item).then(resp => {
			$scope.accounts = item;
			Swal.fire({
				icon: 'success',
				title: 'Cập nhật thành công '
			})
		})
			.catch(error => {
				alert("Lỗi cập nhật");
				console.log("Error", error);
			});
	}
	//// feelback 
	$scope.feelback = {
		contents: "",
		description: "",
		feelbackday: new Date(),
		status: true,
		ratestar: "" 
	}
	$scope.feelbacks = function(user,product) {
	 
		var feelback = angular.copy($scope.feelback);
        if($scope.feelback.ratestar!=''){
			feelback.product={id:product}
		feelback.account={username:user}
		$http.post(`/rest/feelbacks`, feelback).then(resp => { 
			feelback.contents = "";
			feelback.description = "";
			feelback.ratestar = "";
			Swal.fire({
				icon: 'success',
				title: 'Gửi đánh giá thành công '
			})
		})
		}else{
			Swal.fire({
				icon: 'error',
				title: 'Hãy điền form dánh giá '
			})
		}
	}

	$scope.changeImage = function(id) {
		$http.get(`/rest/images/${id}`).then(resp => {
			document.getElementById("view").src = resp.data.url
			console.log(resp.data.url)
		})
	}

	//////// giỏ hàng
	$scope.cart = {
		amount: "",
		colorsize: {id:""}, 
		add(id, user) {
			console.log(this.colorsize.id)
			if (user == 'null') {
				Swal.fire({
					title: 'Hãy đăng nhập '
				})
				location.href = "/security/login/form"
			} else {
				if ((this.colorsize.id !=null  )) {
					$http.get(`/rest/colorsizes/${this.colorsize.id}`).then(resp => {
						$scope.colsize = resp.data;
				
					var item = $scope.items.find(v => v.product.id == id && v.size.id == $scope.colsize .size.id && v.color.id == $scope.colsize .color.id)
					 
					if (item) {  
								item.amount = item.amount + this.amount
								$http.put(`/rest/carts/${item.id}`, item).then(resp => {
									var index = $scope.items.findIndex(p => p.id == item.id);
									$scope.items[index] = item;
									Swal.fire({
										icon: 'success',
										title: 'Đã có ' + item.amount + ' sản phẩm trong giỏ hàng '
									})

								})
						 

					} else {
						$scope.cart = {};
						$scope.cart.color = $scope.colsize.color
						$scope.cart.size = $scope.colsize.size    
								$http.get(`/rest/products/${id}`).then(resp => {
									$scope.cart.product = resp.data
									$scope.cart.amount = this.amount;
									$http.post("/rest/carts", $scope.cart).then(resp => {
										$scope.items.push(resp.data);
										Swal.fire({
											icon: 'success',
											title: 'Thêm sản phẩm vào giỏ hàng thành công'
										})
										location.href = "/cart"
									}).catch(error => {
										console.log(error)
									})
								}).catch({
								}) 

					}
				})
				}
				else {
					Swal.fire({
						icon: 'error',
						title: 'Hãy chọn màu sắc  và size sản phẩm'
					})
				}
			}
		},
		update(item) {
			$http.put(`/rest/carts/${item.id}`, item).then(resp => {
				var index = $scope.items.findIndex(p => p.id == item.id);
				$scope.items[index] = item;
			})
				.catch(error => {
					Swal.fire({
						icon: 'error',
						title: 'Lỗi cập nhật số lương  '
					})
					console.log("Error", error);
				});
		},
		//xóa khỏi giỏ
		remove(id) {
			$http.delete(`/rest/carts/${id}`, id).then(resp => {
				var index = $scope.items.findIndex(p => p.id == id.id);
				$scope.items.splice(index, 1);
				$scope.initialize();
			})
				.catch(error => {
					alert("Lỗi khi xoá sản phẩm");
					console.log("Error", error);
				});
		},
		//tính tổng sp
		get count() {
			return $scope.items.map(item => item.amount).reduce((total, amount) => total += amount, 0)
		},
		//tổng thành tiền
		get mount() {
			return $scope.items.map(item => item.amount * (item.product.price - item.product.price * item.product.discount / 100)).reduce((total, amount) => total += amount, 0)
		}


	}
	$scope.voucher = {}
	//xu lý  đổi voucher
	$scope.voucherPoint = {

		pointchange: "",

		changeVoucher(item) {
			var user = angular.copy(item)
			vouc = {
				account: item,
				status: 1,
				usedday: "",
				expiredday: new Date().setDate(new Date().getDate() + 30),
			};
			do {
				var result = '';
				var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
				var charactersLength = characters.length;
				for (var i = 0; i < 10; i++) {
					result += characters.charAt(Math.floor(Math.random() * charactersLength));
				}
			} while ($scope.voucherAll.find(v => v.vouchercode == result) > 0)

			user.usedpoint = item.usedpoint - this.pointchange;
			vouc.vouchercode = result;

			if (user.usedpoint >= 0) {

				if (this.pointchange == '5000') {

					vouc.vouchername = "giảm 50k ";
					vouc.value = 50000;
				}
				else if (this.pointchange == '10000') {
					vouc.vouchername = "giảm 100K ";
					vouc.value = 100000;
				}
				else if (this.pointchange == '20000') {
					vouc.vouchername = "giảm 200K ";
					vouc.value = 200000;
				}
				else if (this.pointchange == '50000') {
					vouc.vouchername = "giảm 500K ";
					vouc.value = 500000;
				} else {
					alert("Hãy chọn điểm để đổi")
				}
				$http.post(`/rest/vouchers`, vouc).then(resp => {
					Swal.fire({
						icon: 'success',
						title: 'Đổi thành công voucher' + resp.data.vouchername,
						text: 'Trị giá : ' + resp.data.value + ' VND'
					})
					$scope.accounts.usedpoint = item.usedpoint - this.pointchange;
				}).catch(error => {
					console.log(error)

				})
				$http.put(`/rest/accounts/${item.username}`, user).then(resp => {
				}).catch(error => {
					console.log(error)

				})
			}
			else {
				Swal.fire({
					icon: 'error',
					title: 'Bạn không đủ điểm để đổi voucher này',
					text: 'Hãy chọn voucher khác'
				})
			}


		},
		editVoucher() {
			$http.get(`/rest/vouchers/user`).then(resp => {
				$scope.vouche = resp.data
			}).catch(error => {
				console.log(error)

			})
		}
	}



	// xử lý mã giảm giá 
	$scope.price = 0;

	$scope.vouchers = {

		voucher: [],

		check(id) {

			if (id == "") {
				Swal.fire({
					icon: 'error',
					title: 'Hãy nhập mã giảm giá để áp dụng'
				})
			} else {
				$http.get(`/rest/vouchers/${id}`).then(resp => {
					if (resp.data != "") {
						this.voucher = [];
						this.voucher.push(resp.data);
						Swal.fire({
							icon: 'success',
							title: 'Áp dụng mã giảm giá (' + resp.data.vouchername + ') thành công ',
							text: 'Trị giá : ' + resp.data.value + ' VND'
						})
						$scope.price = resp.data.value;

					} else {
						Swal.fire({
							icon: 'error',
							title: 'Mã giảm giá không tồn tại hoặc đã hết hạn',
							text: 'Hãy kiểm tra lại mã giảm giá và hạn sử dụng'
						})
					}


				}).catch(error => {
					Swal.fire({
						icon: 'error',
						title: 'Lỗi áp dụng mã giảm giá'
					})
					console.log(error)

				})
			}
		},

	}
	// Thực hiện đặt hàng

	$scope.order = {
		orderday: new Date(),
		address: "",
		status: "notyet",
		fullname: "",
		numberphone: "",
		time: "",
		payment: '',

		get tableVouchers() {
			return $scope.vouchers.voucher.map(item => {
				return {
					voucher: { vouchercode: item.vouchercode }
				}
			});
		},
		get orderDetails() {
			return $scope.items.map(item => {
				return {
					product: { id: item.product.id },
					price: item.product.price - item.product.price * item.product.discount / 100,
					amount: item.amount,
					size: item.size,
					color: item.color
				}
			});
		},
		purchase(user) {

			var order = angular.copy(this);
			if(order.address==""||order.fullname== "" |order.numberphone==""||order.time=="" ||order.payment==""){
					Swal.fire({
									icon: 'error',
									title: 'Vui lòng nhập đầy đủ thông tin của bạn'
								})
			}else{
			order.account = { username: user }
			// Thực hiện đặt hàng 
			$scope.user = {};
			$http.get(`/rest/orders/count`).then(resp => {
				count = resp.data;
				index = $scope.items.map(item => item.amount * (item.product.price - item.product.price * item.product.discount / 100)).reduce((total, amount) => total += amount, 0) - $scope.price

				if (count < 5) {
					$http.post("/rest/orders", order).then(resp => {
						$http.get(`/rest/accounts/profile`).then(resp => {
							$scope.user = resp.data
							$scope.user.memberpoint = resp.data.memberpoint + (index * 0, 0001)
							$scope.user.usedpoint = resp.data.usedpoint + (index * 0, 0001)
							var us = angular.copy($scope.user);
							
							$http.put(`/rest/accounts/point/${us.username}`, us).then(resp => {
							}).catch(error => {
								Swal.fire({
									icon: 'error',
									title: 'Lỗi point '
								})
								console.log(error)
							})
							
							$http.delete(`/rest/carts/user/${user}`).then(resp => {
							}).catch(error => {
								console.log(error)
							})
						}).catch(error => {
							Swal.fire({
								icon: 'error',
								title: 'Lỗi rest user '
							})
							console.log(error)
						})

						Swal.fire({
							icon: 'success',
							title: 'Đặt hàng thành công ',

						})
						location.href = "/order/list"

					})
						.catch(error => {
							Swal.fire({
								icon: 'error',
								title: 'Lỗi bạn không thể đặt hàng được '
							})
							console.log(error)

						})




				} else {
					Swal.fire({
						icon: 'error',
						title: 'Lỗi bạn không thể đặt hàng',
						text: 'Gần đây bạn đã hủy nhiều đơn hàng '
					})
				}
			}).catch(error => {
				console.log(error)

			})
		}},
		done(id) {
			or: { };
			$http.get(`/rest/orders/${id}`).then(resp => {
				or = resp.data;
			}).catch(error => {
				alert("" + or.price)
				console.log(error)

			})
			Swal.fire({
				title: 'BẠN ĐÃ NHẬN ĐƯỢC HÀNG ?',
				showDenyButton: true,
				showCancelButton: true,
				icon: 'question',
				text: "Xác nhận nếu bạn đã nhận hàng",
				confirmButtonText: 'XÁC NHẬN',
				denyButtonText: `HỦY `,
			}).then((result) => {

				if (result.isConfirmed) {
					$http.put(`/rest/orders/done/${id}`, or).then(resp => {
						Swal.fire({
							icon: 'success',
							title: 'XÁC NHẬN THÀNH CÔNG'

						})
						location.href = "/order/list/done";
					})
				} else if (result.isDenied) {
					Swal.fire({
						icon: 'error',
						title: 'LỖI NHẬN ĐƠN HÀNG '
					})
				}
			})
		},
		notyet(id) {
			or: { };
			$http.get(`/rest/orders/${id}`).then(resp => {
				or = resp.data;
			}).catch(error => {
				console.log(error)

			})
			$http.get(`/rest/orders/count`).then(resp => {
				count = resp.data;

				if (count < 5) {
					Swal.fire({
						title: 'BẠN MUỐN ĐẶT LẠI ĐƠN HÀNG ' + id + ' ?',
						showDenyButton: true,
						showCancelButton: true,
						icon: 'question',
						text: "Xác nhận nếu bạn đã nhận hàng",
						confirmButtonText: 'XÁC NHẬN',
						denyButtonText: `HỦY `,

					}).then((result) => {

						if (result.isConfirmed) {

							$http.put(`/rest/orders/notyet/${id}`, or).then(resp => {
								Swal.fire({
									icon: 'success',
									title: 'ĐẶT HÀNG  THÀNH CÔNG'

								})
								location.href = "/order/list/notyet";
							})
						} else if (result.isDenied) {
							Swal.fire({
								icon: 'error',
								title: 'LỖI ĐẶT HÀNG '
							})
						}
					})
				}
				else {
					Swal.fire({
						icon: 'error',
						title: 'Lỗi bạn không thể đặt hàng',
						text: 'Gần đây bạn đã hủy nhiều  đơn hàng '
					})
				}
			}).catch(error => {

				console.log(error)

			})

		},
		cancel(id) {
			or: { };
			$http.get(`/rest/orders/${id}`).then(resp => {
				or = resp.data;
			}).catch(error => {
				alert("" + or.price)
				console.log(error)

			})
			Swal.fire({
				title: 'BẠN CÓ MUỐN HỦY ĐƠN HÀNG ?',
				input: 'select',
				inputOptions: {

					'NOTLIKE': 'KHÔNG THÍCH SẢN PHẨM ',
					'CANNOT': 'KHÔNG THỂ NHẬN HÀNG',
					'DIFFERENT': 'LÝ DO KHÁC'
				},
				inputPlaceholder: 'LÝ DO BẠN HỦY ?',
				showCancelButton: true,
				inputValidator: (value) => {
					return new Promise((resolve) => {
						if (!(value == '')) {
							or.description = value;
							$http.put(`/rest/orders/${id}`, or).then(resp => {
								Swal.fire({
									icon: 'success',
									title: 'HUỶ ĐƠN HÀNG THÀNH CÔNG'

								})
								location.href = "/order/list/cancel";
							}).catch(error => {
								Swal.fire({
									icon: 'error',
									title: 'LỖI HỦY ĐƠN HÀNG '
								})
								console.log("Error", error);

							})
							resolve()
						} else {
							resolve('HÃY CHỌN LÝ DO BẠN HỦY ?')
						}
					})
				}
			})
		}
	}
	$scope.copy = function(text) {
		var copyText = text
		var input = document.createElement("INPUT");
		document.body.appendChild(input);
		input.value = copyText;
		input.select();
		input.setSelectionRange(0, 99999);
		document.execCommand("copy");
		document.body.removeChild(input);
	}
	$scope.cart.amount = 1;
	$scope.minuAmount = function() {
		if ($scope.cart.amount <= 1) {
			$scope.cart.amount = 1
		} else {
			$scope.cart.amount = $scope.cart.amount - 1
		}
	}
	$scope.plusAmount = function() {
		$scope.cart.amount = $scope.cart.amount + 1

	}


	$scope.imageChange = function(files) {
		var ref = firebase.storage().ref();

		const file = document.querySelector('#image').files[0];
		if (file != null) {
			$http.get(`/rest/accounts/profile`).then(resp => {
				if (resp.data.image != null) {
					var storageRef = firebase.storage().refFromURL(resp.data.image).name
					var desertRef = firebase.storage().ref().child("/USER/" + resp.data.username + "/" + storageRef);
					desertRef.delete().then(() => {
					}).catch((error) => {

					});
				}
				const metadata = {
					contentType: file.type

				};
				const uploadimg = ref.child("/USER/" + resp.data.username + "/" + file.name).put(file, metadata);
				uploadimg.then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
					$http.put(`/rest/accounts/user/images`, url).then(resp => {
						$scope.initialize();
					})
						.catch(error => {
							console.log("Error", error);
						});

				}).catch(console.error);

			})
		}
	}
});
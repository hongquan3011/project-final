app.controller("cate-ctrl", function ($scope, $http) {

    $scope.category = [];
    $scope.form = {};

    $scope.initialize = function () {
        //load category
        $http.get(`/rest/categories`).then(resp => {
            $scope.category = resp.data;

        });
    }
    //khoi dau
    $scope.initialize();

    //xoa form
    $scope.reset = function () {
        $scope.form = {
        };
    }
    //hien thi len form
    $scope.edit = function (item) {
        $scope.form = angular.copy(item);
    }

    //them moi
    $scope.create = function () {
        var item = angular.copy($scope.form);
        item.status = 1;
        $http.post(`/rest/categories`, item).then(resp => {
            $scope.category.push(resp.data);
            $scope.reset();

            Swal.fire({
                icon: 'success',
                title: 'Thêm mới thành công loại'
            })
        }).catch(error => {

            Swal.fire({
                icon: 'error',
                title: 'Lỗi thêm mới loại'
            })
            console.log("Error", error);
        });
    }

    //cap nhat 
    $scope.update = function () {
        var item = angular.copy($scope.form);
        $http.put(`/rest/categories/${item.id}`, item).then(resp => {
            var index = $scope.category.findIndex(p => p.id == item.id);
            $scope.category[index] = item;
            Swal.fire({
                icon: 'success',
                title: 'Cập nhật thành công loại'
            })
        }).catch(error => {

            Swal.fire({
                icon: 'error',
                title: 'Lỗi cập nhật loại'
            })
            console.log("Error", error);
        });
    }

    //mở  
    $scope.open = function (item) {

        $http.put(`/rest/categories/open/${item.id}`, item).then(resp => {
            this.initialize();
            Swal.fire({
                icon: 'success',
                title: 'Đã mở loại'
            })
        }).catch(error => {

            Swal.fire({
                icon: 'error',
                title: 'Lỗi mở loại'
            })
            console.log("Error", error);
        });
    }
    //khóa  
    $scope.lock = function (item) {
        $http.put(`/rest/categories/lock/${item.id}`, item).then(resp => {
            this.initialize();
            Swal.fire({
                icon: 'success',
                title: 'Đã khóa loại'
            })
        }).catch(error => {

            Swal.fire({
                icon: 'error',
                title: 'Lỗi khóa loại'
            })
            console.log("Error", error);
        });
    }

    $scope.pager = {
        page: 0,
        size: 5,
        get category() {
            var start = this.page * this.size;
            return $scope.category.slice(start, start + this.size);
        },
        get count() {
            return Math.ceil(1.0 * $scope.category.length / this.size);
        },
        first() {
            this.page = 0;

        },
        prev() {
            this.page--;
            if (this.page < 0) {
                this.last();
            }
        },
        next() {
            this.page++;
            if (this.page >= this.count) {
                this.first();
            }
        },
        last() {
            this.page = this.count - 1;
        }
    }


});
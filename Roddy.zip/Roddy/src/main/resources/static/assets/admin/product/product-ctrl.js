app.controller("product-ctrl", function ($scope, $http) {

    $scope.products = [];
    $scope.category = [];
    $scope.brand = [];
    $scope.form = {}; 
    $scope.colors = [];
    $scope.sizes = [];
    $scope.images = [];
    $scope.colorSize = [];
    //


    $scope.initialize = function () {
        //load products
        $http.get(`/rest/products`).then(resp => {
            $scope.products = resp.data;

        });
        //load categories
        $http.get(`/rest/categories`).then(resp => {
            $scope.category = resp.data;

        });
        //load Brand
        $http.get(`/rest/brands`).then(resp => {
            $scope.brand = resp.data;

        });
        //load color
        $http.get(`/rest/colors`).then(resp => {
            $scope.colors = resp.data;

        });
        //load sizes
        $http.get(`/rest/sizes`).then(resp => {
            $scope.sizes = resp.data;

        });
    }
    //khoi dau
    $scope.initialize(); 
    //hien thi len form
    $scope.edit = function (item) {  
        $scope.updateform = angular.copy(item);
         
        $http.get(`/rest/colorsizes/product/${item.id}`).then(resp => {
            $scope.setAmount =resp.data.length
        }).catch(error => { 
                console.log("Error", error);
         }); 
    }

    //them moi
    $scope.form = {
        ///
        id: "",
        name: "",
        createDay: new Date(),
        category: { id: "" },
        brand: { id: "" }, 
        status: "",
        discount: "",
        price: "",
        description: "",
        get colorSizes() {
            return $scope.colorSize.map(item => {
                return {
                    color: { id: item.color.id },
                    size: { id: item.size.id },
                    amount: item.amount
                }
            });
        },
        get image() {
            return $scope.images.map(item => {
                return {
                    name: item.name
                }
            });
        }
        , create() {
            var product = angular.copy(this);
            // Thực hiện thêm
            if ($scope.colorSize) {
                var index = $scope.products.findIndex(p => p.id == this.id);
                if (index == -1) {

                    $http.post(`/rest/products`, product).then(resp => {
                        $scope.products.push(resp.data);

                        var ref = firebase.storage().ref();

                        for (var i = 0; i < 6; i++) {
                            const file = document.querySelector('#image').files[i];
                            if (file != null) {
                                const metadata = {
                                    contentType: file.type

                                };
                                const uploadimg = ref.child('/' + resp.data.id + '/' + file.name).put(file, metadata);
                                uploadimg.then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
                                    $http.put(`/rest/images/${resp.data.id}/${file.name}`, url).then(resp => {
                                    })
                                        .catch(error => {
                                            console.log("Error", error);
                                        });

                                }).catch(console.error);
                                console.log(file);
                            }
                        }
                        this.reset();
                        $scope.imageChanged(null)
                        $scope.colorSize = [];
                        Swal.fire({
                            icon: 'success',
                            title: 'Thêm mới thành công '
                        }) 
                    }).catch(error => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Lỗi thêm mới '
                        })
                        console.log("Error", error);
                    });

                } else {
                    Swal.fire({
						icon: 'error',
						title: 'Đã tồn tại mã sản phẩm '
					})
                     
                }
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Hãy chọn màu sắc  và size sản phẩm'
                })
               
            }
        }, reset() { 
            $scope.form.id = "";
            $scope.form.name = ""; 
            $scope.form.status = true;
            $scope.form.price = "";
            $scope.form.discount = "";
            $scope.form.image = "";
            $scope.form.description = "";
            $scope.images = [];
            $scope.imageNew = [];
        }
    }
    $scope.updateform = {
        ///
        id: "",
        name: "",
        category: { id: "" },
        brand: { id: "" }, 
        status: "",
        discount: "",
        price: "",
        description: ""
    }
    $scope.update = function () {
        var product = angular.copy($scope.updateform);
        var index = $scope.products.findIndex(p => p.id == $scope.updateform.id);
        alert(index)
        if (index > -1) {
            $http.put(`/rest/products/${product.id}`, product).then(resp => {
                Swal.fire({
                    icon: 'success',
                    title: 'Cập nhật sản phẩm thành công'
                }) 
                $scope.products[index] = resp.data;
            })
                .catch(error => {
                    Swal.fire({
						icon: 'error',
						title: 'Lỗi không thể cập nhật'
					})
                    console.log("Error", error);
                });
        }  

    }

    //mở  
    $scope.open = function (item) {

        $http.put(`/rest/products/open/${item.id}`, item).then(resp => {
            this.initialize();
            Swal.fire({
				icon: 'success',
				title: 'Đã mở sản phẩm'
			})
        })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi khi mở sản phẩm'
                })
                console.log("Error", error);
            });
    }
    //khóa  
    $scope.lock = function (item) {
        $http.put(`/rest/products/lock/${item.id}`, item).then(resp => {
            this.initialize();
            Swal.fire({
				icon: 'success',
				title: 'Đã khóa sản phẩm'
			})
        })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi khi khóa sản phẩm'
                })
                console.log("Error", error);
            });
    }


    //check product  cho color và size

    $scope.add = {};
    $scope.update = {};
    $scope.editColorSize = [];
    $scope.product = {};
    $scope.editColorSizes = function (product) {
        $scope.editColorSize = [];
        $scope.product=angular.copy(product);
        $scope.update = {};
        $http.get(`/rest/colorsizes/product/${product.id}`).then(resp => {
            $scope.editColorSize =resp.data
        }).catch(error => { 
                console.log("Error", error);
         }); 
    }
    $scope.deleteColorSizes= function (id) { 
        $http.delete(`/rest/colorsizes/${id}`).then(resp => {
            var index = $scope.editColorSize.findIndex(i => i.id ==   id  )
            $scope.editColorSize.splice(index, 1)
        }).catch(error => { 
                console.log("Error", error);
         });    
    }
    $scope.copyColorSizes = function (item) {
        $scope.update =angular.copy(item); 
    }
    $scope.updateColorSizes = function () {
          var colsize=angular.copy($scope.update)  
          colsize.product=$scope.product;
        if (colsize.color   != null && colsize.size  != null && colsize.amount > 0 ) { 
            var index = $scope.editColorSize.findIndex(i => i.color.id == colsize.color.id && i.size.id == colsize.size.id)
            
                   if( index==-1 ){
                    $http.post(`/rest/colorsizes`,colsize).then(resp => {     
                        $scope.editColorSizes($scope.product)  
                        $scope.update = {};
                        colsize=null;
                        }).catch(error => { 
                                console.log("Error", error);
                         }); 
                   }if( index!=-1 ){
                    $http.put(`/rest/colorsizes/${colsize.id}`,colsize).then(resp => {     
                        $scope.editColorSizes($scope.product)  
                        $scope.update = {};
                        colsize=null;
                        }).catch(error => { 
                                console.log("Error", error);
                         }); 
                   }
                         
                            
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Hãy thêm các trường đầy đủ'
            }) 
        }
    }
    $scope.addColorSize = function () { 
        var colsize = angular.copy($scope.add);
        if (colsize.color != null && colsize.size != null && colsize.amount > 0) {
            var index = $scope.colorSize.findIndex(i => i.color.id == colsize.color.id && i.size.id == colsize.size.id)

            if (index == -1) {
                $scope.colorSize.push({ color: colsize.color, size: colsize.size, amount: colsize.amount })
                console.log($scope.colorSize)
            } else {
                $scope.colorSize[index] = { color: colsize.color, size: colsize.size, amount: colsize.amount };
                console.log($scope.colorSize)
            }
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Hãy thêm các trường đầy đủ'
            }) 
        }
    };
    $scope.deleteColorSize = function (item) {
        var index = $scope.colorSize.findIndex(i => i.color.id == item.color.id && i.size.id == item.size.id)
        if (index > -1) {
            $scope.colorSize.splice(index, 1)
        }

    };

    
    //check img 
    $scope.selectImg = [];
    $scope.checkImg = function (item) {
        var index = $scope.selectImg.findIndex(i => i.id == item.id);
        if (index > -1) {
            $scope.selectImg.splice(index, 1);
            console.log(this.selectImg)
        } else {
            $scope.selectImg.push(item);
            console.log(this.selectImg)
        }
    }
    //xóa img
    $scope.deleteImg = function () {
        for (var i = 0; i < $scope.selectImg.length; i++) {
            var desertRef = firebase.storage().ref().child("/" + $scope.selectImg[i].product.id + "/" + $scope.selectImg[i].name);
            desertRef.delete().then(() => {
            }).catch((error) => {
                console.log("Error", error);
            });
            $http.delete(`/rest/images/${$scope.selectImg[i].id}`).then(resp => {
                $scope.selectImg = [];
            }).catch(error => {

            })
            var is = $scope.selectImg[i].id;
            var index = $scope.images.findIndex(i => i.id === is);
            $scope.images.splice(index, 1);
            console.log($scope.selectImg)
        }
    }
    // color / size


    //edit img  
     
    $scope.editImg = function (product) {
        $scope.images = [];
        $scope.product = product;
        $http.get(`/rest/images/product/${product.id}`).then(resp => {
            $scope.images = resp.data;
        })
    }
    $scope.imageCheck = {};
    $scope.imageInt = 0;
    $scope.imgs = [];
    //upload hinh
    $scope.imageNew = [];
    $scope.imageChangedUpdate = function (files) {
        $scope.imageNew = [];
        if (files != null) {
            var count = 6 - $scope.images.length;
            if (parseInt(files.length) > count) { 
                Swal.fire({
                    icon: 'error',
                    title: 'Tối đa 6 hình ảnh cho một sản phẩm',
                    text:'Bạn chỉ có thể thêm được ' + count + 'sản phẩm' 
                }) 
            } else {
                $scope.imgs = [];
                for (var i = 0; i < count; i++) {
                    const file = document.querySelector('#imageUpdate').files[i];
                    var data = new FormData();
                    if (file != null) {
                        //$scope.images.push(file.name);
                        data.append('file', file);
                        if ($scope.images.findIndex(i => i.name == file.name) < 0) {
                            $scope.imgs.push({ name: file.name });
                            $http.post('/rest/upload/images', data, {
                                transformRequest: angular.identity,
                                headers: { 'Content-Type': undefined }
                            }).then(resp => {
                                $scope.imageNew.push(resp.data);
                            }).catch(error => {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Lỗi tải  hình ảnh'
                                }) 
                                console.log("Error", error);
                            })
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Hình ảnh đã tồn tại hoặc trùng tên hình ảnh hiện có'+file.name ,
                                text:'Hãy đổi tên hoặc chọn ảnh khác'
                            }) 
                            var idx = $scope.imageNew.findIndex(i => i.name === file.name)
                            $scope.imageNew.splice(idx, 1);
                        }
                    }
                }
            }
        }

    }
    //lưu ảnh update
    $scope.imageUpdate = {

        get image() {
            return $scope.imgs.map(item => {
                return {
                    name: item.name,
                    product: { id: $scope.product.id }
                }
            });
        },
        add() {
            if ($scope.imageNew.length != 0) {
                var img = angular.copy(this);
                $http.post(`/rest/images`, img).then(resp => {

                    var ref = firebase.storage().ref();
                    for (var i = 0; i <= 6 - $scope.images.length; i++) {
                        const file = document.querySelector('#imageUpdate').files[i];
                        if (file != null) {
                            const metadata = {
                                contentType: file.type

                            };
                            const uploadimg = ref.child('/' + $scope.product.id + '/' + file.name).put(file, metadata);
                            uploadimg.then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
                                $http.put(`/rest/images/${$scope.product.id}/${file.name}`, url).then(resp => {
                                    $scope.images.push(resp.data);
                                })
                                    .catch(error => {
                                        console.log("Error", error);
                                    });

                            }).catch(console.error);
                            console.log(file);
                        }
                    } $scope.imageNew = [];
                }).catch(console.error);
            }

        }
        , reset() { $scope.imageNew = []; }
    }
    //load ảnh form thêm
    $scope.imageChanged = function (files) {
        $scope.imageNew = [];
        if (files != null) {
            if (parseInt(files.length) > 6) {
                Swal.fire({
                    icon: 'error',
                    title: 'Tối đa 6 hình ảnh cho một sản phẩm', 
                })
                $scope.images = [];
            } else {
                $scope.images = [];
                for (var d = 0; d < 6; d++) {
                    const file = document.querySelector('#image').files[d];
                    var data = new FormData();
                    if (file != null) {
                        //$scope.images.push(file.name);
                        data.append('file', file);
                        if ($scope.images.findIndex(i => i.name == file.name) < 0) {
                            $scope.images.push({ name: file.name });
                            $http.post('/rest/upload/images', data, {
                                transformRequest: angular.identity,
                                headers: { 'Content-Type': undefined }
                            }).then(resp => {
                                $scope.imageNew.push(resp.data);
                            }).catch(error => {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Lỗi tải  hình ảnh'
                                }) 
                                console.log("Error", error);
                            })
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Hình ảnh đã tồn tại hoặc trùng tên hình ảnh hiện có'+file.name ,
                                text:'Hãy đổi tên hoặc chọn ảnh khác'
                            }) 
                           
                            var idx = $scope.imageNew.findIndex(i => i.name === file.name)
                            $scope.imageNew.splice(idx, 1);
                        }


                    }
                }
            }
        }

    }
    //phan trang
    $scope.pager = {
        page: 0,
        size: 10,
        get products() {
            var start = this.page * this.size;
            return $scope.products.slice(start, start + this.size);
        },
        get count() {
            return Math.ceil(1.0 * $scope.products.length / this.size);
        },
        first() {
            this.page = 0;
        },
        prev() {
            this.page--;
            if (this.page < 0) {
                this.last();
            }
        },
        next() {
            this.page++;
            if (this.page >= this.count) {
                this.first();
            }
        },
        last() {
            this.page = this.count - 1;
        }
    }
})
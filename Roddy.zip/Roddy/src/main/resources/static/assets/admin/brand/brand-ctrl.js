app.controller("brand-ctrl", function ($scope, $http) {

    $scope.brands = [];
    $scope.form = {};

    $scope.initialize = function () {
        //load brands
        $http.get(`/rest/brands`).then(resp => {
            $scope.brands = resp.data;

        });
    }
    //khoi dau
    $scope.initialize();

    //xoa form
    $scope.reset = function () {
        $scope.form = {
        };
    }
    //hien thi len form
    $scope.edit = function (item) {
        $scope.form = angular.copy(item);
    }

    //them moi
    $scope.create = function () {
        var item = angular.copy($scope.form);
        item.status = true;
        var index = $scope.brands.find(p => p.id == item.id);
        if (index == null) {
            if ($scope.image != null) {
                $http.post(`/rest/brands`, item).then(resp => {
                    $scope.brands.push(resp.data);

                    var ref = firebase.storage().ref();
                    const file = document.querySelector('#image').files[0];
                    const metadata = {
                        contentType: file.type

                    };
                    const uploadimg = ref.child("/BRAND/" + item.id + "/" + $scope.image).put(file, metadata);
                    uploadimg.then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
                        resp.data.image = url;
                        $scope.image = null;
                        $http.put(`/rest/brands/${resp.data.id}`, resp.data).then(resp => {
                            $scope.initialize();
                        })
                            .catch(error => {
                                console.log("Error", error);
                            });

                    }).catch(console.error);
                    $scope.reset();
                    Swal.fire({
                        icon: 'success',
                        title: 'Thêm mới thành công thuoqng hiệu', 
                    }) 
                }).catch(error => { 
                    Swal.fire({
                        icon: 'error',
                        title: 'Lỗi thêm mới thương hiệu '
                    })
                    console.log("Error", error);
                });
            } else {

                Swal.fire({
                    icon: 'error',
                    title: 'Hãy chọn hình ảnh thương hiệu '
                })
            }
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Đã tồn tại mã thương hiệu '
            })
        }

    }

    //cap nhat 
    $scope.update = function () {
        var item = angular.copy($scope.form);
        $http.put(`/rest/brands/${item.id}`, item).then(resp => {
            var index = $scope.brands.findIndex(p => p.id == item.id);
            $scope.brands[index] = item;
            if ($scope.imageUpdate != null) {
                if (resp.data.image != null) {
                    var storageRef = firebase.storage().refFromURL(resp.data.image).name
                    var desertRef = firebase.storage().ref().child("/BRAND/" + resp.data.id + "/" + storageRef);
                    desertRef.delete().then(() => {
                    }).catch((error) => {

                    });

                }
                var ref = firebase.storage().ref();
                const file = document.querySelector('#imageUpdate').files[0];
                const metadata = {
                    contentType: file.type

                };
                const uploadimg = ref.child("/BRAND/" + resp.data.id + "/" + $scope.imageUpdate).put(file, metadata);
                uploadimg.then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
                    resp.data.image = url
                    $http.put(`/rest/brands/${resp.data.id}`, resp.data).then(resp => {
                        $scope.initialize();
                    })
                        .catch(error => {
                            console.log("Error", error);
                        });

                }).catch(console.error);
            }
            Swal.fire({
                icon: 'success',
                title: 'Cập nhật thành công thương hiệu'
            })
        })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi cập nhật thương hiệu '
                })
                console.log("Error", error);
            });
    }

    $scope.open = function (item) {

        $http.put(`/rest/brands/open/${item.id}`, item).then(resp => {
            this.initialize();
            Swal.fire({
                icon: 'success',
                title: 'Đã mở thương hiệu '
            })
        })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi khi mở thương hiệu '
                })
                console.log("Error", error);
            });
    }
    //khóa  
    $scope.lock = function (item) {
        $http.put(`/rest/brands/lock/${item.id}`, item).then(resp => {
            this.initialize();
            Swal.fire({
                icon: 'success',
                title: 'Đã khóa thương hiệu '
            })
        })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi khi khóa thương hiệu '
                })
                console.log("Error", error);
            });
    }

    //hinh anh
    $scope.image = null;
    $scope.imageUpdate = null;
    $scope.imageChange = function (files) {
        var data = new FormData();
        data.append('file', files[0]);
        $scope.form.image = files[0].name
        $http.post('/rest/upload/images', data, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        }).then(resp => {
            $scope.image = resp.data.name;
        }).catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Lỗi tải lên hình ảnh '
            })
            console.log("Error", error);
        })
    }
    $scope.imageChangeUpdate = function (files) {
        var data = new FormData();
        data.append('file', files[0]);
        $scope.imageUpdate = files[0].name
        $http.post('/rest/upload/images', data, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        }).then(resp => {
            $scope.form.image = null;
            $scope.imageUpdate = resp.data.name;
        }).catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Lỗi tải lên hình ảnh '
            })
            console.log("Error", error);
        })
    }
    //phan trang
    $scope.pager = {
        page: 0,
        size: 5,
        get brands() {
            var start = this.page * this.size;
            return $scope.brands.slice(start, start + this.size);
        },
        get count() {
            return Math.ceil(1.0 * $scope.brands.length / this.size);
        },
        first() {
            this.page = 0;
        },
        prev() {
            this.page--;
            if (this.page < 0) {
                this.last();
            }
        },
        next() {
            this.page++;
            if (this.page >= this.count) {
                this.first();
            }
        },
        last() {
            this.page = this.count - 1;
        }
    }


});
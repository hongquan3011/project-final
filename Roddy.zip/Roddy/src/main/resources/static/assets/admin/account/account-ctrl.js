app.controller("account-ctrl",function($scope, $http){

    $scope.accounts = [];
    $scope.form = {};
    $scope.initialize = function(){
        //load
        $http.get(`/rest/accounts`).then(resp => {
            $scope.accounts = resp.data;           
         
        });     
    }
    //khoi dau
    $scope.initialize();

    //xoa form
    $scope.reset = function(){
	    $scope.image=null;
        $scope.form = {    
            createday:new Date()    
        };
    }
    //hien thi len form
    $scope.edit = function(item){ 
        $scope.form = angular.copy(item);      
        $scope.form.image = item.image;    
        $scope.image=null; 
    }

    //them moi
    $scope.create = function(){
        var item = angular.copy($scope.form)
        var index = $scope.accounts.findIndex(p => p.username == item.username);
        if(index==-1){
            item.createday= new Date();                    
            $http.post(`/rest/accounts`, item).then(resp => {         
                $scope.accounts.push(resp.data);
                var ref = firebase.storage().ref(); 
                const file = document.querySelector('#image').files[0];
                        const metadata = {
                            contentType: file.type
        
                        };
                        const uploadimg = ref.child("/USER/" + resp.data.username + "/" + $scope.image).put(file, metadata);
                        uploadimg.then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
                            resp.data.image=url;
                            $http.put(`/rest/accounts/${resp.data.username}`, resp.data).then(resp => {
                                $scope.initialize();
                            })
                                .catch(error => {
                                    console.log("Error", error);
                                });
        
                        }).catch(console.error);
        
    
    
               $scope.reset();
               Swal.fire({
				icon: 'success',
				title: 'Thêm mới tài khoản thành công'
			})
            }).catch(error =>{
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi khi thêm mới  tài khoản ' 
                }) 
                console.log("Error", error);
            });
        }else{
            Swal.fire({
                icon: 'error',
                title: 'Đã tồn tại tài khoản ' 
            })
        }
       
    }

    //cap nhat 
    $scope.update = function(){ 
        var item = angular.copy($scope.form);

        $http.put(`/rest/accounts/${item.username}`, item).then(resp => {
            var index = $scope.accounts.findIndex(p => p.username == item.username);
            $scope.accounts[index] = item;

            if ($scope.imageUpdate  != null  )  { 
                if(resp.data.image!=null){
                    var storageRef = firebase.storage().refFromURL(resp.data.image).name
                var desertRef = firebase.storage().ref().child("/USER/" + resp.data.username + "/" + storageRef);
                desertRef.delete().then(() => {
                }).catch((error) => {

                });
         
                }
                var ref = firebase.storage().ref(); 
                const file = document.querySelector('#imageUpdate').files[0];
            const metadata = {
                contentType: file.type

            };
            const uploadimg = ref.child("/USER/" + resp.data.username + "/" + $scope.imageUpdate).put(file, metadata);
            uploadimg.then(snapshot => snapshot.ref.getDownloadURL()).then(url => {
                resp.data.image=url
                $http.put(`/rest/accounts/${resp.data.username}`, resp.data).then(resp => {
                    $scope.initialize();
                })
                    .catch(error => {
                        console.log("Error", error);
                    });

            }).catch(console.error);
        }
        Swal.fire({
            icon: 'success',
            title: 'Cập nhật tài khoản thành công'
        })
            $scope.initialize();
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Lỗi cập nhật tài khoản ' 
            })
            console.log("Error", error);
        });
    }

    //xoa 
     $scope.open = function (item) {

        $http.put(`/rest/accounts/open/${item.username}`, item).then(resp => {
            this.initialize();
            Swal.fire({
				icon: 'success',
				title: 'Đã mở tài khoản'
			})
            
        })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi khi mở tài khoản ' 
                }) 
                console.log("Error", error);
            });
    }
    //khóa  
    $scope.lock = function (item) {
        $http.put(`/rest/accounts/lock/${item.username}`, item).then(resp => {
            this.initialize();
            Swal.fire({
				icon: 'success',
				title: 'Đã khóa tài khoản'
			})
        })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi khi khóa tài khoản ' 
                }) 
                console.log("Error", error);
            });
    }
   
    //upload hinh
    $scope.image=null;
    $scope.imageUpdate =null; 
     $scope.imageChanged = function(files){
        var data = new FormData();
        data.append('file', files[0]);
        $scope.form.image = files[0].name 
        $http.post('/rest/upload/images', data, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }).then(resp => {
            $scope.image = resp.data.name;
        }).catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Lỗi tải lên hình ảnh ' 
            })  
            console.log("Error", error);
        })
    }

    $scope.imageChangedUpdate = function(files){
        var data = new FormData();
        data.append('file', files[0]);
        $scope.imageUpdate = files[0].name 
        $http.post('/rest/upload/images', data, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }).then(resp => {
            $scope.form.image = null;
            $scope.image = resp.data.name;
        }).catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Lỗi tải lên hình ảnh ' 
            })
            console.log("Error", error);
        })
    }
    //upload hinh 
//phan trang
    $scope.pager = {
        page: 0,
        size: 5,
        get accounts(){
            var start = this.page*this.size;
            return $scope.accounts.slice(start, start + this.size);
        },
        get count(){
            return Math.ceil(1.0 * $scope.accounts.length / this.size);
        },
        first(){
            this.page = 0;
        },
        prev(){
            this.page--;
            if(this.page < 0){
                this.last();
            }
        },
        next(){
            this.page++;
            if(this.page >= this.count){
                this.first();
            }
        },
        last(){
            this.page = this.count - 1;
        }
    }
});
   
   

app.controller("color-ctrl",function($scope, $http){
    $scope.colors = [];
    $scope.form = {};

    $scope.initialize = function(){
        //load products
        $http.get(`/rest/colors`).then(resp => {
            $scope.colors = resp.data;           
         
        });     
    }
    //khoi dau
    $scope.initialize();

    //xoa form
    $scope.reset = function(){
        $scope.form = {        
        };
    }
    //hien thi len form
    $scope.edit = function(item){
        $scope.form = angular.copy(item);        
    }

    //them moi
    $scope.create = function(){
        var item = angular.copy($scope.form);
        $http.post(`/rest/colors`, item).then(resp => {         
            $scope.colors.push(resp.data);
           $scope.reset();
           Swal.fire({
            icon: 'success',
            title: 'Thêm mới thành công màu' 
        })  
        }).catch(error =>{
            
            Swal.fire({
                icon: 'error',
                title: 'Lỗi thêm mới màu' 
            })
            console.log("Error", error);
        });
    }

    //cap nhat 
    $scope.update = function(){
        var item = angular.copy($scope.form);
        $http.put(`/rest/colors/${item.id}`, item).then(resp => {
            var index = $scope.colors.findIndex(p => p.id == item.id);
            $scope.colors[index] = item;
            Swal.fire({
                icon: 'success',
                title: 'Đã cập nhật màu' 
            })  
            }).catch(error =>{
                
                Swal.fire({
                    icon: 'error',
                    title: 'Lỗi cập nhật màu' 
                })
            console.log("Error", error);
        });
    }

   $scope.pager = {
        page: 0,
        size: 5,
        get colors() {
            var start = this.page * this.size;
            return $scope.colors.slice(start, start + this.size);
        },
        get count() {
            return Math.ceil(1.0 * $scope.colors.length / this.size);
        },
        first() {
            this.page = 0;
            
        },
        prev() {
            this.page--;
            if (this.page < 0) {
                this.last();
            }
        },
        next() {
            this.page++;
            if (this.page >= this.count) {
                this.first();
            }
        },
        last() {
            this.page = this.count - 1;
        }
    }


   
   
    
});
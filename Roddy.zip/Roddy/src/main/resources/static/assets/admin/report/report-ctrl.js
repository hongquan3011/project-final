app.controller("report-ctrl", function($scope, $http) {
    var listin = [];
    var listbymoth = [];
    var listbyyear = [];
    $scope.revenueByYear = [];
    ////tồn kho theo loại
    $scope.initlaze = function() {



        $http.get(`/rest/report/inventory`).then(resp => {
            for (var i = 0; i < resp.data.length; i++) {
                listin.push({ name: resp.data[i][0], count: resp.data[i][1] })
                $scope.inventory = resp.data;


            }
            $scope.drawChartinventory();
        });
        $http.get(`/rest/report/revenueByMonth`).then(resp => {
            for (var i = 0; i < resp.data.length; i++) {
                listbymoth.push({ moth: resp.data[i][0], revenue: resp.data[i][2] })
                $scope.revenueByMonths = resp.data;
            }

            $scope.revenueMoth();
        });
        $http.get(`/rest/report/revenueByYear`).then(resp => {
            for (var i = 0; i < resp.data.length; i++) {
                listbyyear.push({ year: resp.data[i][0], count: resp.data[i][1], revenue: resp.data[i][2] })
                $scope.revenueByYear = resp.data;

            }
            $scope.revenueYear();

        });
    }

    $scope.initlaze();

    $scope.revenueMoth = function() {
        google.charts.load('current', { 'packages': ['corechart'] });

        // Draw the pie chart and bar chart when Charts is loaded.
        google.charts.setOnLoadCallback(drawChartByMoth);

        function drawChartByMoth() {

            var data = new google.visualization.DataTable();
            data.addColumn('number', 'Tháng');
            data.addColumn('number', 'Số lượng');
            data.addColumn('number', 'Doanh thu');
            for (var i = 0; i < listbymoth.length; i++) {
                var n = listbymoth[i].moth;
                var m = listbymoth[i].count;
                var q = listbymoth[i].revenue;
                data.addRows([
                    [n, m, q]
                ]);
            }
            var barchart_options = {
                title: 'Doanh thu theo tháng',
                width: 400,
                height: 300,
                legend: 'none'
            };
            var barchart = new google.visualization.BarChart(document.getElementById('revenueMoths'));
            barchart.draw(data, barchart_options);
        }
    }

    ////////////////////
    $scope.drawChartinventory = function() {
            // Load the Visualization API and the piechart package.
            google.load('visualization', '1.0', { 'packages': ['corechart'] });
            google.setOnLoadCallback(drawChartinventorys);

            function drawChartinventorys() {
                // Create the data table.
                var data = new google.visualization.DataTable();
                // Create columns for the DataTable        
                data.addColumn('string');
                data.addColumn('number');
                for (var i = 0; i < listin.length; i++) {
                    var n = listin[i].name;
                    var m = listin[i].count;
                    data.addRows([
                        ['' + n, m]
                    ]);
                }
                //Create option for chart
                var options = {
                    'width': 1500,
                    'height': 600
                };
                // Instantiate and draw our chart, passing in some options.
                var chart1 = new google.visualization.PieChart(document.getElementById('inventory'));
                chart1.draw(data, options);
            }
        }
        ///chart tồn kho
    $scope.revenueYear = function() {
            google.charts.load('current', { 'packages': ['line'] });
            google.charts.setOnLoadCallback(revenueYears);

            function revenueYears() {


                var data = new google.visualization.DataTable();
                data.addColumn('string', 'Year');
                data.addColumn('number', 'Revenue');
                for (var i = 0; i < listbyyear.length; i++) {
                    var n = listbyyear[i].year;
                    var m = listbyyear[i].revenue;
                    data.addRows([
                        ['' + n, m]
                    ]);
                }
                var options = {
                    chart: {
                        title: 'Doanh thu theo năm',
                        subtitle: 'VND'
                    },
                    width: 900,
                    height: 500
                };

                var chart2 = new google.charts.Line(document.getElementById('revenueYears'));

                chart2.draw(data, google.charts.Line.convertOptions(options));
            }
        }
        ///

})
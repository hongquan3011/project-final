app.controller("imp-ctrl",function($scope, $http){
    $scope.import_invoices = [];
    $scope.form = {};

    $scope.initialize = function(){
        //load kho
        $http.get(`/rest/import_invoices`).then(resp => {
            $scope.import_invoices = resp.data;           
         
        });     
    }
    //khoi dau
    $scope.initialize();

    //xoa form
    $scope.reset = function(){
        $scope.form = {        
        };
    }
    //hien thi len form
    $scope.edit = function(item){
        $scope.form = angular.copy(item);        
    }
    

			
			//them moi
    $scope.create = function(){
        var item = angular.copy($scope.form);
        $http.post(`/rest/import_invoices`, item).then(resp => {         
            $scope.import_invoices.push(resp.data);
           $scope.reset();
            alert("Thêm mới thành công!");
        }).catch(error =>{
            alert("Lỗi thêm mới!");
            console.log("Error", error);
        });
    }

    //cap nhat 
    $scope.update = function(){
        var item = angular.copy($scope.form);
        $http.put(`/rest/import_invoices/${item.id}`, item).then(resp => {
            var index = $scope.import_invoices.findIndex(p => p.id == item.id);
            $scope.import_invoices[index] = item;
            alert("cập nhật thành công!");
        })
        .catch(error => {
            alert("Lỗi cập nhật");
            console.log("Error", error);
        });
    }

   //mở  
    $scope.open = function(item){
	
        $http.put(`/rest/import_invoices/open/${item.id}`, item).then(resp => {
            this.initialize();
            alert("Đổi  thành công!");
        })
        .catch(error => {
            alert("Lỗi khi xoá ");
            console.log("Error", error);
        });
    }
     //khóa  
    $scope.lock = function(item){
        $http.put(`/rest/import_invoices/lock/${item.id}`, item).then(resp => {
           this.initialize();
            alert("Đổi  thành công!");
        })
        .catch(error => {
            alert("Lỗi khi khóa ");
            console.log("Error", error);
        });
    }


 
   
    
});
app.controller("order-ctrl", function($scope, $http) {
	$scope.orders = [];
	$scope.form = {};
	$scope.detail=[];
	
	$scope.initialize = function() {
		//load order
		$http.get(`/rest/orders`).then(resp => {
			$scope.orders = resp.data;
			
this.form = {};
		this.detail = [];
		});
	
	}
	//khoi dau
	$scope.initialize();
 
		$scope.find = function(id) {
			
			if (id == 1) {
				$http.get(`/rest/orders/find/notyet`).then(resp => {
					this.orders = resp.data;
				}).catch(error => {

					console.log(error)

				})
			} else if (id == 2) {
				$http.get(`/rest/orders/find/delivery`).then(resp => {
					this.orders = resp.data;
				}).catch(error => {

					console.log(error)

				})
			} else if (id == 3) {
				$http.get(`/rest/orders/find/done`).then(resp => {
					this.orders = resp.data;
				}).catch(error => {

					console.log(error)

				})
			} else {
				$http.get(`/rest/orders/find/cancel`).then(resp => {
					this.orders = resp.data;
				}).catch(error => {

					console.log(error)

				})
			}
this.form = {};
		this.detail = [];

		}, 
	$scope.details = function(order){
		 
		$http.get(`/rest/orders/detail/${order.id}`).then(resp => {
					 $scope.detail= resp.data; 
					  
					 }
					).catch(error => {

					console.log(error)

				})
				$scope.form = angular.copy(order);	
			$(".nav-tabs  button:eq(0)").tab('show')
		 
	},
	
$scope.loadcancel = function() {
		//load order
		$http.get(`/rest/orders/find/cancel`).then(resp => {
			$scope.orders = resp.data;

		});
		 
	}
	$scope.loaddelivery = function() {
		//load order
		$http.get(`/rest/orders/find/delivery`).then(resp => {
			$scope.orders = resp.data;

		});
	}
	//cap nhat 
	$scope.update = function(item) {
		$http.put(`/rest/orders/delivery/${item.id}`,item).then(resp => {
								$(".nav-tabs  button:eq(3)").tab('show')
								this.loaddelivery();
							}).catch(error => {
								
								console.log("Error", error);

							});
						
	}				

	//huy 
	$scope.cancel = function(item) { 
			Swal.fire({
				title: 'KHÔNG TIẾP NHẬN ĐƠN HÀNG ?',
				input: 'select',
				inputOptions: {

					'AdminOutOfStock': 'HẾT HÀNG',
					'AdminCovid': 'KHÔNG THỂ GIAO HÀNG (VÌ DỊCH BỆNH)' ,
					'AdminBoom': 'KHÁCH HÀNG KHÔNG NHẬN HÀNG  ' 
					
				},
				inputPlaceholder: 'LÝ DO BẠN HỦY ?',
				showCancelButton: true,
				inputValidator: (value) => {
					return new Promise((resolve) => {
						if (!(value=='')) {
							item.description = value;
							$http.put(`/rest/orders/cancel/${item.id}`,item).then(resp => {
								Swal.fire({
									icon: 'success',
									title: 'HUỶ ĐƠN HÀNG THÀNH CÔNG'

								}) 
								$(".nav-tabs  button:eq(5)").tab('show')
										this.loadcancel();
							}).catch(error => {
								Swal.fire({
									icon: 'error',
									title: 'LỖI HỦY ĐƠN HÀNG '
								})
								console.log("Error", error);

							})
							resolve()
						} else {
							resolve('HÃY CHỌN LÝ DO BẠN HỦY ?')
						}
					})
				}
			})
		 
	}
	//phan trang
	$scope.pager = {
		page: 0,
		size: 6,
		get orders() {
			var start = this.page * this.size;
			return $scope.orders.slice(start, start + this.size);
		},
		get count() {
			return Math.ceil(1.0 * $scope.orders.length / this.size);
		},
		first() {
			this.page = 0;
		},
		prev() {
			this.page--;
			if (this.page < 0) {
				this.last();
			}
		},
		next() {
			this.page++;
			if (this.page >= this.count) {
				this.first();
			}
		},
		last() {
			this.page = this.count - 1;
		}
	}



});
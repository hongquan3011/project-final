window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});

window.addEventListener('DOMContentLoaded', event => {
    // Simple-DataTables
    // https://github.com/fiduswriter/Simple-DataTables/wiki

    const datatablesSimple = document.getElementById('datatablesSimple');
    if (datatablesSimple) {
        new simpleDatatables.DataTable(datatablesSimple);
    }
});
var app = angular.module("app", ["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
        .when("/product", {
            templateUrl: "product/product.html",
            controller: "product-ctrl"
        })
        .when("/account", {
            templateUrl: "account/account.html",
            controller: "account-ctrl"
        })
        .when("/brand", {
            templateUrl: "brand/brand.html",
            controller: "brand-ctrl"
        })
        .when("/category", {
            templateUrl: "category/category.html",
            controller: "cate-ctrl"
        })
        .when("/order", {
            templateUrl: "order/order.html",
            controller: "order-ctrl"
        })
        .when("/kho", {
            templateUrl: "importImp/importImp.html",
            controller: "imp-ctrl"
        })
        .when("/color", {
            templateUrl: "color/color.html",
            controller: "color-ctrl"
        })
        .when("/voucher", {
            templateUrl: "voucher/voucher.html",
            controller: "voucher-ctrl"
        })
        .when("/feelback", {
            templateUrl: "feelback/feelback.html",
            controller: "feelback-ctrl"
        })
        .when("/size", {
            templateUrl: "size/size.html",
            controller: "size-ctrl"
        }).when("/countOrder", {
            templateUrl: "report/countOrders.html",
            controller: "report-ctrl"
        })
        .when("/revenueByYear", {
            templateUrl: "report/revenueByYear.html",
            controller: "report-ctrl"
        }).when("/revenueByMonth", {
            templateUrl: "report/revenueByMonth.html",
            controller: "report-ctrl"
        }).when("/inventory", {
            templateUrl: "report/inventory.html",
            controller: "report-ctrl"
        })
        .otherwise({
            templateUrl: "home/dashboard.html",
            controller: "report-ctrl"
        });
})
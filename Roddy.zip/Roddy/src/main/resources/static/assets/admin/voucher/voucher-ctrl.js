app.controller("voucher-ctrl",function($scope, $http){
    $scope.vouchers = [];
    $scope.form = {};

    $scope.initialize = function(){
        //load products
        $http.get(`/rest/vouchers`).then(resp => {
            $scope.vouchers = resp.data;           
         
        });     
    }
    //khoi dau
    $scope.initialize();

    //xoa form
    $scope.reset = function(){
        $scope.form = {        
        };
    } 
    
});
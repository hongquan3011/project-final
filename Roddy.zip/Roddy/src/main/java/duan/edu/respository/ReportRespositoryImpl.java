package duan.edu.respository;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import duan.edu.entity.Category;
import duan.edu.entity.Product;
@Repository
@Transactional
public class ReportRespositoryImpl implements ReportRespository{

//	@Autowired
//	private Session sessionFactory;
//
//	@Override
//	public List<Object[]> cateReport() {
//		// TODO Auto-generated method stub
//		Session session = sessionFactory.getSession();
//		CriteriaBuilder b = session.getCriteriaBuilder();
//		CriteriaQuery<Object[]> q = b.createQuery(Object[].class);
//		Root rootP = q.from(Product.class);
//		Root rootC = q.from(Category.class);
//		q.where(b.equal(rootP.get("category"), rootC.get("id")));
//		q.multiselect(rootC.get("id"), rootC.get("name"), b.count(rootP.get("id")));
//		q.groupBy(rootC.get("id"));
//		Query query = session.createQuery(q);
//		return query.getResultList();
//	}
	
}

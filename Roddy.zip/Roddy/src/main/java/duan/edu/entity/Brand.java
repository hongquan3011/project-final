package duan.edu.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity; 
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
@SuppressWarnings("serial")
@Entity 
@Data
@Table(name ="Brands")
public class Brand implements Serializable{
	@Id
	@Column(columnDefinition = "varchar(15)")
	String id;
	@Column(columnDefinition = "nvarchar(50)",nullable = false)
	String name;
	@Column(columnDefinition = "nvarchar(250)")
	String image;
	@Column
	Boolean status;
	@JsonIgnore
	@OneToMany(mappedBy = "brand")
	List<Product> product;
}

package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity; 
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min; 

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "Products")
public class Product implements Serializable {
	@Id	
	@Column(columnDefinition = "varchar(25)",nullable = false) 
	String id; 	
	@Column(columnDefinition = "nvarchar(100)",nullable = false) 
	String name; 
	@Column(nullable = false)
 
	@Min(1)  
	Float price; 
	@Column(columnDefinition = "nvarchar(250)") 
	String description;
	@Column()
	@Min(0)   
	Float discount;
	@Temporal(TemporalType.DATE)
	@Column(name = "createDay",nullable = false)
	   @DateTimeFormat(pattern = "dd/MM/yyyy")
	Date createDay = new Date();
	@Column(nullable = false)
	Boolean status;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<Image> image;
	@ManyToOne
	@JoinColumn(name = "brand")
	Brand brand;
	@ManyToOne
	@JoinColumn(name = "category")
	Category category;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<OrderDetail> orderdetail ;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<Feelback> feelback  ;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<ImportInvoices> importinvoices   ;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<Cart> cart ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<ColorSize>   colorSizes;
}
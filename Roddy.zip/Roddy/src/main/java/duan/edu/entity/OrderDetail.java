 
package duan.edu.entity;

import java.io.Serializable; 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;  

import lombok.Data;


@SuppressWarnings("serial")
@Data

@Entity 
@Table(name = "Orderdetails")
public class OrderDetail  implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	Integer id; 
 
	@Min(1) 
	@Column(nullable = false)
	Integer amount;
	@Column(nullable = false) 
	@Min(1)  
	Float price;
	@ManyToOne
	@JoinColumn(name = "product")
     Product product;  
	@ManyToOne
	@JoinColumn(name = "orderid")
	Order orders;
	@ManyToOne
    @JoinColumn(name = "color")
    Color color;
	@ManyToOne
    @JoinColumn(name = "size")
    Size size;
}

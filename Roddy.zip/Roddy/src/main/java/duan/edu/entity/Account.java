package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany; 
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min; 

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;



@SuppressWarnings("serial")
@Entity 
@Data
@Table(name ="Accounts")
public class Account implements Serializable{
	@Id
	@Column(columnDefinition = "varchar(25)") 
	String username;
	@Column(columnDefinition = "varchar(50)",nullable = false)  
	String password;
	@Column(columnDefinition = "nvarchar(50)")
	String fullname;
	@Column(columnDefinition = "varchar(12)")
	String numberphone;
	@Column(columnDefinition = "varchar(50)",nullable = false)
	@Email 
	String email;
	@Temporal(TemporalType.DATE)
	   @DateTimeFormat(pattern = "dd/MM/yyyy")
	@JoinColumn(name = "createday")
	Date createday= new Date();
	@Column(columnDefinition = "nvarchar(250)")
	String image;
	@Column(columnDefinition = "nvarchar(250)")
	String address;
	@Column()
	Boolean gender;
	@Column()
	Boolean status;
	 @Column  
		@Min(0)
		Integer Memberpoint;
		@Column 
		@Min(0)
		Integer Usedpoint;
	 
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<Order> orders;
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<Voucher> voucher;
 
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<Feelback> feelback ;
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<ImportInvoices> importinvoices ;
	@JsonIgnore
	@OneToMany(mappedBy = "account", fetch = FetchType.EAGER)
	List<Authority> authorities;
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<Cart> cart;
}

package duan.edu.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity; 
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table; 
 

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity 
@Table(name = "Colors")
public class Color  implements Serializable{ 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;
	@Column(columnDefinition = "nvarchar(25)",nullable = false) 
String name;
	@JsonIgnore
	@OneToMany(mappedBy = "color")
	List<Cart> cart;
	@JsonIgnore
	@OneToMany(mappedBy = "color")
	List<OrderDetail>  orderDetails;
	@JsonIgnore
	@OneToMany(mappedBy = "color")
	List<ColorSize>   colorSizes;
}

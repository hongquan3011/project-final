package duan.edu.entity;
 
 
import lombok.Data;


import javax.persistence.*;
import javax.validation.constraints.Max; 
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date; 
@SuppressWarnings("serial")
@Entity 
@Data
@Table(name= "Feelbacks")
public class Feelback implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer id;
    @Column(columnDefinition = "nvarchar(50)") 
    String contents;
    @Column(columnDefinition = "nvarchar(255)") 
    String description; 
    @Temporal(TemporalType.DATE)
    @Column(name = "feelbackday",nullable = false)
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    Date feelbackday = new Date();
  	Boolean status;
    @Column(name = "ratestar")
    @Max(5)
  	 Integer ratestar;
    
    @ManyToOne
   	@JoinColumn(name = "product")
   	Product product;
     @ManyToOne
   	@JoinColumn(name = "account")
   	Account account;
    
  }

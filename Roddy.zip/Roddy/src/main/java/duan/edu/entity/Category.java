package duan.edu.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table; 

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
@SuppressWarnings("serial")
@Entity 
@Data
@Table(name ="Categories")
public class Category implements Serializable{
	@Id
	@Column(columnDefinition = "varchar(15)") 
	String id;
	@Column(columnDefinition = "nvarchar(50)",nullable = false) 
	String name;
	@Column(nullable = false)
	Boolean status;
	@Column(columnDefinition = "nvarchar(50)",nullable = false ) 
	String section;
	@JsonIgnore
	@OneToMany(mappedBy = "category",fetch = FetchType.EAGER)
	List<Product> product;
}

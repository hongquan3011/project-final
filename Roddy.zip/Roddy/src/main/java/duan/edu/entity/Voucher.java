package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity; 
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType; 
import javax.validation.constraints.Min; 
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@SuppressWarnings("serial")
@Entity 
@Data
@Table(name = "Vouchers")
public class Voucher  implements Serializable{
	@Id
	@Column(columnDefinition = "varchar(10)",nullable = false) 
	String vouchercode; 
	@Column(columnDefinition = "nvarchar(50)",nullable = false) 
	String vouchername;
	@Column(nullable = false)
	@Min(1) 
	Double value;
	@Column(nullable = false)
	Boolean status;
	@Temporal(TemporalType.DATE) 
	@Column(name = "expiredday",nullable = false)
	   @DateTimeFormat(pattern = "dd/MM/yyyy")
	Date expiredday;
	@Temporal(TemporalType.DATE)
	@Column(name = "usedday")
	   @DateTimeFormat(pattern = "dd/MM/yyyy")
	Date usedday;
	 
	@JsonIgnore
	@OneToMany(mappedBy = "voucher")
	List<TableVoucher> tableVoucher;
	@ManyToOne
	@JoinColumn(name = "username")
	Account account;
}

package duan.edu.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.dao.ReportDAO;

@CrossOrigin("*")
@RestController
@RequestMapping("rest/report")
public class ReportRestController {
@Autowired
ReportDAO dao;
@GetMapping("inventory")
public List<Object[]> inventory(){
	return dao.inventory();
	
}
@GetMapping("revenueByMonth")
public List<Object[]> revenueByMonth(){
	return dao.revenueByMonth();
	
}
@GetMapping("revenueByYear")
public List<Object[]> revenueByYear(){
	return dao.revenueByYear();
	
}
//@GetMapping("count")
//public List<Object[]> count() {
//	return dao.countOrders();
//}
}

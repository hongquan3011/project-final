package duan.edu.restcontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.entity.Account;
import duan.edu.entity.Voucher;
import duan.edu.service.AccountService;
import duan.edu.service.VoucherService;

@CrossOrigin("*")
@RestController
@RequestMapping("/rest/vouchers")
public class VoucherRestController {
	@Autowired 
	VoucherService voucherService;
	@Autowired 
	AccountService  accountService;
	@GetMapping("{id}")
	public Voucher getOne(@PathVariable("id") String id) { 
		return voucherService.findByVouchercode(id); 
		
		
	}
	
	@GetMapping()
	public List<Voucher> getAll() {
		return voucherService.findAll();
		
	}
	@GetMapping("http")
	public List<Voucher> getUser(HttpServletRequest request ) {
		Account account=accountService.findById(request.getRemoteUser());
		return voucherService.findByAccount(account);
		
	}
	@PostMapping
	public Voucher create(@RequestBody Voucher Voucher) {
		return voucherService.create(Voucher);
	}
	
	
	

	@PutMapping("lock/{vouchercode}")
	public Voucher lock(@PathVariable("vouchercode") String vouchercode,@RequestBody Voucher Voucher) {
		Voucher.setStatus(false);
		return voucherService.update(Voucher);
	}
	@PutMapping("open/{vouchercode}")
	public Voucher open(@PathVariable("vouchercode") String vouchercode,@RequestBody Voucher Voucher) {
		Voucher.setStatus(true);
		
		return voucherService.update(Voucher);
	}
	 
}

package duan.edu.restcontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.entity.Account;

import duan.edu.entity.ImportInvoices;

import duan.edu.service.AccountService;

import duan.edu.service.ImportInvoicesService;


@CrossOrigin("*")
@RestController
@RequestMapping("/rest/import_invoices")
public class ImportRestController {
	@Autowired
	ImportInvoicesService impservice;
	
	@Autowired
	AccountService accountService;
	
 @GetMapping("{id}")
 	public ImportInvoices getOne(@PathVariable("id") Integer id) {
 	return impservice.findById(id);
 }
	
	@GetMapping()
	public List<ImportInvoices> getAll() {
		return impservice.findAll();
		
	}
	
	@PostMapping
	public ImportInvoices create( @RequestBody ImportInvoices imp, HttpServletRequest request) {
		Account account = accountService.findById(request.getRemoteUser());
		imp.setAccount(account);
		return impservice.create(imp);
	}
	
	@PutMapping("{id}")
	public ImportInvoices update(@PathVariable("id") Integer id,@RequestBody ImportInvoices imp) {
		return impservice.update(imp);
	}

 
}

package duan.edu.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.entity.Category;
import duan.edu.service.CategoryService;


@CrossOrigin("*")
@RestController
@RequestMapping("/rest/categories")
public class CategoryRestController {
	@Autowired
	CategoryService CategoryService;
 
	
	@GetMapping()
	public List<Category> getAll() {
		return CategoryService.findAll();
		
	}
	
	@PostMapping
	public Category create(@RequestBody Category cate) {
		return CategoryService.create(cate);
	}
	
	@PutMapping("{id}")
	public Category update(@PathVariable("id") String id,@RequestBody Category cate) {
		return CategoryService.update(cate);
	}
	
	@PutMapping("lock/{id}")
	public Category lock(@PathVariable("id") String id,@RequestBody Category cate) {
		cate.setStatus(false);
		return CategoryService.update(cate);
	}
	@PutMapping("open/{id}")
	public Category open(@PathVariable("id") String id,@RequestBody Category cate) {
		cate.setStatus(true);
		return CategoryService.update(cate);
	}
	
}

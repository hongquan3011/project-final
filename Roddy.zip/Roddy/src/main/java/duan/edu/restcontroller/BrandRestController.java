package duan.edu.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.entity.Brand;
import duan.edu.entity.Category;
import duan.edu.service.BrandService;


@CrossOrigin("*")
@RestController
@RequestMapping("/rest/brands")
public class BrandRestController {
	@Autowired
	BrandService BrandService;
	
//	@GetMapping("{id}")
//	public Color getOne(@PathVariable("id") Integer id) {
//		return ColorService.findById(id);
//	}
	
	@GetMapping()
	public List<Brand> getAll() {
		return BrandService.findAll();
		
	}
	
	@PostMapping
	public Brand create(@RequestBody Brand Brand) {
		return BrandService.create(Brand);
	}
	
	@PutMapping("{id}")
	public Brand update(@PathVariable("id") String id,@RequestBody Brand Brand) {
		return BrandService.update(Brand);
	}
	

	@PutMapping("lock/{id}")
	public Brand lock(@PathVariable("id") String id,@RequestBody Brand brand) {
		brand.setStatus(false);
		return BrandService.update(brand);
	}
	@PutMapping("open/{id}")
	public Brand open(@PathVariable("id") String id,@RequestBody Brand brand) {
		brand.setStatus(true);
		return BrandService.update(brand);
	}
	
}

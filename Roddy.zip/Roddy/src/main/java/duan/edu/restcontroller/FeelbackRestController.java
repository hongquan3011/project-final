package duan.edu.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.entity.Feelback;
import duan.edu.service.FeelbackService;


@CrossOrigin("*")
@RestController
@RequestMapping("/rest/feelbacks")
public class FeelbackRestController {
	@Autowired 
	FeelbackService FeelbackService;
	
	@GetMapping()
	public List<Feelback> getAll() {
		return FeelbackService.findAll();
		
	}
	@PostMapping
	public Feelback create(@RequestBody Feelback Feelback) {
		return FeelbackService.create(Feelback);
	}
	
	@PutMapping("lock/{id}")
	public Feelback lock(@PathVariable("id") Integer id,@RequestBody Feelback Feelback) {
		Feelback.setStatus(false);
		return FeelbackService.update(Feelback);
	}
	@PutMapping("open/{id}")
	public Feelback open(@PathVariable("id") Integer id,@RequestBody Feelback Feelback) {
		Feelback.setStatus(true);
		return FeelbackService.update(Feelback);
	}
}

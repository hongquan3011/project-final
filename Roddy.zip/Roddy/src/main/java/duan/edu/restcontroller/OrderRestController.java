package duan.edu.restcontroller;
 

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;

import duan.edu.dao.ReportDAO;
import duan.edu.entity.Account;
import duan.edu.entity.Order;
import duan.edu.entity.OrderDetail;
import duan.edu.service.AccountService;
import duan.edu.service.OrderDetailService;
import duan.edu.service.OrderService;
 

@CrossOrigin("*")
@RestController
@RequestMapping("/rest/orders")
public class OrderRestController {
	@Autowired
	OrderService orderService;
	@Autowired
	OrderDetailService orderDetailService;
	@Autowired
	ReportDAO dao;
	@Autowired
	AccountService accountService;
	@PutMapping("{id}")
	public Order update(@PathVariable("id") Integer id,@RequestBody Order order) { 
		order.setStatus("cancel");
		return orderService.save(order);
	}
	@GetMapping("{id}")
	public Order getOne(@PathVariable("id") Integer id) {  
		return orderService.findById(id);
	}
	@GetMapping("count")
  	public Long count( HttpServletRequest   request) {  
      String username = request.getRemoteUser();
      Account ACC= accountService.findById(username);
        List<Order> or= orderService.findTop10ByUsername(ACC);
 	 
		 int count= 0;
 	 for (Order order : or) {
			if (order.getStatus().equals("cancel") && order.getDescription()!=null ) {
				if( order.getDescription().equals("CANNOT")||order.getDescription().equals("NOTLIKE")||order.getDescription().equals("DIFFERENT")) {
					count+=1;
				}
			} 
		}  
		return  (long) count;
	}
	@PostMapping
	public Order create(@RequestBody JsonNode orderData  ) { 
		 
		return orderService.create(orderData);
	}
	@GetMapping()
	public List<Order> getAll() {
		return orderService.findAllDesc();
	}
	@GetMapping("find/{status}")
	public List<Order> findByStatus(@PathVariable("status") String status) { 
		return orderService.findByStatus(status);
	}
	@GetMapping("detail/{id}")
	public List<OrderDetail> getOrderDetail1(@PathVariable("id") Integer  id) {  
		 
		return orderDetailService.findByOrderId(id);
	}
	@PutMapping("delivery/{id}")
	public Order Delivery(@PathVariable("id") Integer id,@RequestBody Order order) { 
		order.setStatus("delivery"); 
		return orderService.save(order);
	}
	@PutMapping("done/{id}")
	public Order done(@PathVariable("id") Integer id,@RequestBody Order order) { 
		order.setStatus("done"); 
		return orderService.save(order);
	}
	@PutMapping("notyet/{id}")
	public Order notyet(@PathVariable("id") Integer id,@RequestBody Order order) { 
		order.setOrderday(new Date());
		order.setDescription("");
		order.setStatus("notyet"); 
		return orderService.save(order);
	}
	@PutMapping("cancel/{id}")
	public Order cancel(@PathVariable("id") Integer id,@RequestBody Order order) { 
		order.setStatus("cancel");
	
		return orderService.save(order);
	}
 

}

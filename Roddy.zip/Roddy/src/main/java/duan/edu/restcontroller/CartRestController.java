package duan.edu.restcontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.entity.Cart;
import duan.edu.entity.Color;
import duan.edu.service.AccountService;
import duan.edu.service.CartService;
import duan.edu.service.ColorService;


@CrossOrigin("*")
@RestController
@RequestMapping("/rest/carts")
public class CartRestController {
@Autowired
CartService cartService;
@Autowired
AccountService accountService;
@Autowired
ColorService colorService;
@GetMapping()
public List<Cart> findAllByUsername(HttpServletRequest request){
	  String username = request.getRemoteUser();
	  List<Cart> list =cartService.findByUsername(username);
	return list ;
}
@PostMapping()
public Cart add(HttpServletRequest request,@RequestBody Cart cart) {
	  String username = request.getRemoteUser();
	  cart.setAccount(accountService.findById(username));  
	return cartService.create(cart);
}
@DeleteMapping("{id}")
public void delete(@PathVariable("id") Integer id) {
 cartService.delete(id);
 }	
@DeleteMapping("user/{user}")
public void deleteUser(@PathVariable("user") String user) {
	System.out.println(user);
 cartService.deleteUser(user);
 }	
@PutMapping("{id}")
public Cart update(@PathVariable("id") Integer id,@RequestBody Cart cart) {
	return cartService.update(cart);
}

}

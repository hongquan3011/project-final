package duan.edu.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Image;
import duan.edu.service.ImageService; 
@CrossOrigin("*")
@RestController
@RequestMapping("/rest/images")
public class ImageRestController {
	@Autowired
	ImageService imageService;
	 
	@GetMapping("{id}")
	public  Image getOne(@PathVariable ("id") Integer id) {
		return imageService.findById(id);
		
	}
	@GetMapping("product/{id}")
	public List<Image> getByProduct(@PathVariable ("id") String id) {
		return imageService.findbyProduct(id);
		
	}
	@PostMapping()
	public  List<Image>  add(@RequestBody   JsonNode image) {   
				return imageService.create(image);
	}
	@PutMapping("{product}/{name}")
	public  Image  setUrl(@PathVariable ("product") String id,@PathVariable ("name") String name,@RequestBody   String url) {  
		Image img= imageService.findbyProductIdAndName(id,name);
		img.setUrl(url); 
				return imageService.update(img);
	}
	@DeleteMapping("{id}")
	public   void  delete(@PathVariable ("id") Integer id ) {  
				  imageService.delete(id);
	}
	 
	}

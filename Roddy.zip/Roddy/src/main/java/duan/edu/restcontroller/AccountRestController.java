package duan.edu.restcontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import duan.edu.entity.Account;
import duan.edu.entity.Category;
import duan.edu.service.AccountService;

@CrossOrigin("*")
@RestController
@RequestMapping("/rest/accounts")
public class AccountRestController {

	@Autowired 
	AccountService AccountService;

	@GetMapping()
	public List<Account> getAll() {
		return AccountService.findAll();
		
	}
	@GetMapping("profile")
	public Account findByUsername(HttpServletRequest request){		 
		String username = request.getRemoteUser();
		if(username !=null) {
			 Account account =AccountService.findById(username);
			 return account;
		}else {
			return null;
		}
		
	}
	@PutMapping("point/{username}")
	public Account point(@PathVariable("username") String username,@RequestBody Account account) {
		return AccountService.update(account);
	}

	@PostMapping
	public Account create(@RequestBody Account account) {
		return AccountService.create(account);
	}
	
	@PutMapping("{username}")
	public Account update(@PathVariable("username") String username,@RequestBody Account account) {
		return AccountService.update(account);
	}
	 
	@PutMapping("open/{username}")
	public Account open(@PathVariable("username") String username,@RequestBody Account account) {
		account.setStatus(true);
		return AccountService.update(account);
	}
	@PutMapping("lock/{username}")
	public Account lock(@PathVariable("username") String username,@RequestBody Account account) {
		account.setStatus(false);
		return AccountService.update(account);
	}
	@PutMapping("user/images")
	public Account images(HttpServletRequest request, @RequestBody String url) {
		String username = request.getRemoteUser();
		 
			 Account account =AccountService.findById(username);
		   account.setImage(url);
		return AccountService.update(account);
	}
	
}

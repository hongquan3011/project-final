package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import duan.edu.dao.TableVoucherDao;
import duan.edu.entity.TableVoucher;
import duan.edu.service.TableVoucherService; 
@Service
public class  TableVoucherServiceImpl implements TableVoucherService{
	@Autowired
	TableVoucherDao dao;

	@Override
	public List<TableVoucher> findByOrderId(Integer id) {
		// TODO Auto-generated method stub
		return dao.findByOrderId( id);
	}
	
}

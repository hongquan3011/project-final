package duan.edu.service;

import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Cart;

public interface CartService {
List<Cart> findByUsername(String username);

List<Cart> findAll();

void delete(Integer id);

Cart update(Cart cart);

Cart create(Cart cart);

void deleteUser(String user);
 
}

 
package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.ImportInvoicesDAO;
import duan.edu.entity.Color;
import duan.edu.entity.ImportInvoices;
import duan.edu.service.ImportInvoicesService; 
@Service
public class ImportInvoicesServiceImpl implements ImportInvoicesService {
@Autowired
ImportInvoicesDAO dao;

@Override
public List<ImportInvoices> findAll() {
	return dao.findAll();
}

@Override
public ImportInvoices findById(Integer id) {
	return dao.findById(id).get();
}



@Override
public ImportInvoices create(ImportInvoices imp) {
	return dao.save(imp);
}

@Override
public ImportInvoices update(ImportInvoices imp) {
	return dao.save(imp);
}


  
}

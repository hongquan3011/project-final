package duan.edu.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Category;
import duan.edu.entity.Product;

/**
 * @author FPTShop
 *
 */
public interface ProductService {
	
	List<Product> findAll();
	Product findById(String id);

	Page<Product> findByNameContainingAndStatus(String search,Pageable pageable);
Page<Product> findByBrand(String brand,Boolean status,Pageable pageable);
	Page<Product> findByCategory(String category,Boolean status,Pageable pageable);
	Product create(JsonNode ProductData);

	Product update(Product product);

	Page<Product> findAllByStatus(Pageable pageable);
	Page<Product> findBySection(String string,Pageable pageable);
	List<Product> findAllDesc();   
	List<Product> findAllByCategorySectionAndStatusOrderByCreateDayDesc(String string, boolean b);
	List<Product> findTop4ByCategorySectionAndStatusOrderByCreateDayDesc(String string, boolean b);

}

package duan.edu.service;

import java.util.List;

import duan.edu.entity.Category;

public interface CategoryService {

	Category findById(String id);

	List<Category> findAllByStatus();

	Category create(Category product);

	Category update(Category product);

	List<Category> findAll();

	Category findBySection(String string);
 
}

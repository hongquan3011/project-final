package duan.edu.service;

import java.util.List;


import duan.edu.entity.Feelback;

public interface FeelbackService {
	
	Feelback findById(Integer id);

	List<Feelback> findAll();

	

	Feelback update(Feelback product);

	List<Feelback> findByProductId(String id);

	Feelback create(Feelback feelback);

	

}

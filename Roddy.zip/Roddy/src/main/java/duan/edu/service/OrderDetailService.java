package duan.edu.service;

import java.util.List;

import duan.edu.entity.OrderDetail;

public interface OrderDetailService {

	List<OrderDetail> findByOrderId(Integer id);
 

	 
	 
 

}

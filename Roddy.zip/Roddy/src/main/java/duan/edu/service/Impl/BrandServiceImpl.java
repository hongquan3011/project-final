package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.BrandDAO;
import duan.edu.entity.*;
import duan.edu.service.BrandService;

@Service
public class BrandServiceImpl implements BrandService{
@Autowired
BrandDAO dao;
@Override
public List<Brand> findAll() {
	return dao.findAllDesc();
}

@Override
public Brand findById(String id) {
	return dao.findById(id).get();
}




@Override
public Brand create(Brand Brand) {
	return dao.save(Brand);
}

@Override
public Brand update(Brand Brand) {
	return dao.save(Brand);
}


@Override
public List<Brand> findAllByStatus() {
	// TODO Auto-generated method stub
	return dao.findAllByStatus();
}

}

package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.CategoryDAO;
import duan.edu.entity.*;
import duan.edu.service.CategoryService;
@Service
public class CategoryServiceImpl implements CategoryService {
@Autowired
CategoryDAO dao;

@Override
public List<Category> findAll() {
	return dao.findAllDesc();
}

@Override
public Category findById(String id) {
	return dao.findById(id).get();
}




@Override
public Category create(Category Loai) {
	return dao.save(Loai);
}

@Override
public Category update(Category Loai) {
	return dao.save(Loai);
}

@Override
public List<Category> findAllByStatus() {
	// TODO Auto-generated method stub
	return dao.findAllByStatus();
}

@Override
public Category findBySection(String string) {
	// TODO Auto-generated method stub
	return dao.findBySection(string);
}
  
}



package duan.edu.service;

import java.util.List;

import duan.edu.entity.Brand;

public interface BrandService {

	Brand findById(String id);

	List<Brand> findAllByStatus();
	List<Brand> findAll();
	Brand create(Brand product);

	Brand update(Brand product);

	
}

package duan.edu.service.Impl;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import duan.edu.dao.ColorSizeDAO;
import duan.edu.dao.ImageDAO;
import duan.edu.dao.ProductDAO; 
import duan.edu.entity.ColorSize;
import duan.edu.entity.Image; 
import duan.edu.entity.Product; 
import duan.edu.service.ProductService;
@Service
public class ProductServiceImpl implements ProductService {
@Autowired
ProductDAO dao;
@Autowired
ColorSizeDAO colorSizeDAO;
 

@Autowired
ImageDAO imgdao;
@Override
public Page<Product> findAllByStatus(Pageable pageable) {
	// TODO Auto-generated method stub
	return dao.findAllByStatus(pageable);
}

@Override
public Product findById(String id) {
	// TODO Auto-generated method stub
	return dao.findById(id).get();
}

@Override
public Page<Product> findByNameContainingAndStatus(String search, Pageable pageable) {
	// TODO Auto-generated method stub
	return dao.findByNameContainingAndStatus(search,pageable);
}


@Override
public Page<Product> findByBrand(String brand, Boolean status, Pageable pageable) {
	// TODO Auto-generated method stub
	return dao.findByBrandIdAndStatus(brand, status, pageable);
}

@Override
public Product update(Product product) {
	return dao.save(product);
}


@Override
public Page<Product> findByCategory(String category, Boolean status, Pageable pageable) {
	// TODO Auto-generated method stub
	return dao.findByCategoryIdAndStatus(category, status, pageable);
}





@Override
public List<Product> findAllDesc() {
	// TODO Auto-generated method stub
	return dao.findAllDesc();
}

@Override
public List<Product> findAll() {
	// TODO Auto-generated method stub
	return dao.findAll();
}

@Override
public Page<Product> findBySection(String name, Pageable pageable) {
	// TODO Auto-generated method stub
	return dao.findBySection(name, pageable);
}

@Override
public Product create(JsonNode productData) {
	ObjectMapper mapper = new ObjectMapper();
	Product product = mapper.convertValue(productData, Product.class);
	dao.save(product);
	TypeReference<List<ColorSize>> tbl = new TypeReference <List<ColorSize>>() {};
	List<ColorSize> colorsize= mapper.convertValue(productData.get("colorSizes"), tbl)
			.stream().peek(p -> p.setProduct(product)).collect(Collectors.toList());
	colorSizeDAO.saveAll(colorsize);
	 
	TypeReference<List<Image>> img = new TypeReference <List<Image>>() {};
	List<Image> image = mapper.convertValue(productData.get("image"), img)
			.stream().peek(p -> p.setProduct(product)).collect(Collectors.toList());
	imgdao.saveAll(image);
	return product;
}

@Override
public List<Product> findAllByCategorySectionAndStatusOrderByCreateDayDesc(String string, boolean b) {
	// TODO Auto-generated method stub
	return dao.findAllByCategorySectionAndStatusOrderByCreateDayDesc(string,b);
}

@Override
public List<Product> findTop4ByCategorySectionAndStatusOrderByCreateDayDesc(String string, boolean b) {
	// TODO Auto-generated method stub
	return dao.findTop4ByCategorySectionAndStatusOrderByCreateDayDesc(string,b);
}
 
  
}

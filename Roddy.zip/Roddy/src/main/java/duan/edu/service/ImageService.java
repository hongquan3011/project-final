package duan.edu.service;

import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Image;
 
public interface ImageService {
	List<Image> findbyProduct(String id); 
	List<Image> findAll();
 
	Image update(Image img);

	List<Image> create(JsonNode images);
 
	Image findbyProductIdAndName(String id, String name);

	void delete(Integer id);
	 Image findById(Integer id);
 
 
}

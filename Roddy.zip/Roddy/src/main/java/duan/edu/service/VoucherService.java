package duan.edu.service;

import java.util.List;

import duan.edu.entity.Account;
import duan.edu.entity.Voucher;

public interface VoucherService {
	
Voucher  findByVouchercode(String id);


List<Voucher> findAll();

Voucher create(Voucher orders);

Voucher update(Voucher orders);

void delete(Integer id);


List<Voucher> findByAccount(Account account);

 



} 

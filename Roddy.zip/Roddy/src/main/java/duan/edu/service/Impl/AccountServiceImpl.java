package duan.edu.service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.AccountDAO;
import duan.edu.entity.*;
import duan.edu.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDAO dao;

	@Override
	public List<Account> findAll() {
		return dao.findAll();
	}
	
	@Override
	public Account findById(String username) {
		// TODO Auto-generated method stub
		return dao.findById(username).get();
	}

	@Override
	public List<Account> getAdministrators() {
		// TODO Auto-generated method stub
		return dao.getAdministrators();
	}
	
	
	@Override
	public Account create(Account account) {
		return dao.save(account);
	}

	@Override
	public Account update(Account account) {
		return dao.save(account);
	}
	
	@Override
	public void delete(String username) {
		dao.deleteById(username);
	}

	@Override
	public Account save(Account account) {
		// TODO Auto-generated method stub
		return dao.save(account);
	}


}

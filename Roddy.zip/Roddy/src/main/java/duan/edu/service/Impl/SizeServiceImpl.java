package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.SizeDAO;


import duan.edu.service.SizeService;

import duan.edu.entity.*;
@Service
public class SizeServiceImpl implements SizeService {
@Autowired
SizeDAO dao;

@Override
public List<Size> findAll() {
	return dao.findAll();
}

@Override
public Size findById(Integer id) {
	return dao.findById(id).get();
}



@Override
public Size create(Size Size) {
	return dao.save(Size);
}

@Override
public Size update( Size Size) {
	return dao.save(Size);
}
 


}

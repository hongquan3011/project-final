package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.ColorSizeDAO;
 
import duan.edu.service.ColorSizeService; 

import duan.edu.entity.*;
@Service
public class ColorSizeServiceImpl implements ColorSizeService {
@Autowired
ColorSizeDAO dao;

@Override
public List<ColorSize> findbyProduct(String id) {
	// TODO Auto-generated method stub
	return dao.findbyProduct(id);
}

@Override
public void delete(Integer id) {
	// TODO Auto-generated method stub
	dao.deleteById(id);
}

@Override
public List<ColorSize> findAll() {
	// TODO Auto-generated method stub
	return dao.findAll();
}

@Override
public ColorSize create(ColorSize tbl) {
	// TODO Auto-generated method stub
	return dao.save(tbl);
}

@Override
public ColorSize update(ColorSize tbl) {
	// TODO Auto-generated method stub
	return dao.save(tbl);
}

 

@Override
public  ColorSize findById(Integer id) {
	// TODO Auto-generated method stub
	return dao.findById(id).get();
}


 
}

 
package duan.edu.service.Impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import duan.edu.dao.OrderDetailDAO;
import duan.edu.dao.TableVoucherDao;
import duan.edu.dao.OrderDAO;
import duan.edu.entity.Account;
import duan.edu.entity.Order;
import duan.edu.entity.OrderDetail;
import duan.edu.entity.TableVoucher; 
import duan.edu.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
@Autowired
OrderDAO dao;
@Autowired
OrderDetailDAO ctdao;
@Autowired
TableVoucherDao tvcdao;
@Override
public List<Order> findbyUsername(String username) {
	return dao.findbyUsername(username);
}
@Override
public Order findById(Integer id) {
	return dao.findById(id).get();
}
@Override
public Order create(JsonNode orderData) {
	ObjectMapper mapper = new ObjectMapper(); 
	Order order = mapper.convertValue(orderData, Order.class);
	dao.save(order);
	TypeReference<List<OrderDetail>> type = new TypeReference <List<OrderDetail>>() {};
			List<OrderDetail> details = mapper.convertValue(orderData.get("orderDetails"), type)
	.stream().peek(d -> d.setOrders(order)).collect(Collectors.toList()); 
			ctdao.saveAll(details);  
			TypeReference<List<TableVoucher>> types = new TypeReference <List<TableVoucher>>() {};
			List<TableVoucher> voucher = mapper.convertValue(orderData.get("tableVouchers"), types)
	.stream().peek(d -> d.setOrder(order)).collect(Collectors.toList()); 
	        tvcdao.saveAll(voucher);
	        
	return order;

} 
@Override
public Order save(Order order) {
	// TODO Auto-generated method stub
	return dao.save(order);
}
@Override
public List<Order> findByStatusAndUsername(String id, String username) {
	return dao.findByStatusAndUsername(id,  username);
}
@Override
public Long count(String user) {
	 
	return dao.count();
}
@Override
public List<Order> findAllDesc() {
	
	return dao.findAllDesc();
}
@Override
public List<Order> findByStatus(String status) {
	
	return dao.findByStatusOrderByOrderdayDesc(status);
}
@Override
public List<Order> findAll() {
 
	return dao.findAll();
}
 
@Override
public List<Order> findTop10ByUsername(Account acc) {
	return dao.findTop10ByAccountOrderByOrderdayDesc(acc);
}


}

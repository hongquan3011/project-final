 
package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.VoucherDAO;
import duan.edu.entity.Account;
import duan.edu.entity.Voucher;
import duan.edu.service.VoucherService; 
@Service
public class VoucherServiceImpl implements VoucherService {
@Autowired
VoucherDAO dao;

@Override
public Voucher findByVouchercode(String id) { 
	return dao.findByVouchercode(id);
}

@Override
public List<Voucher> findAll() {
	return dao.findAll();
}

@Override
public Voucher create(Voucher Voucher) {
	return dao.save(Voucher);
}

@Override
public Voucher update(Voucher Voucher) {
	return dao.save(Voucher);
}

@Override
public void delete(Integer id) {
	dao.deleteById(id);
}

@Override
public List<Voucher> findByAccount(Account account) {
	// TODO Auto-generated method stub
	return dao.findByAccountOrderByExpireddayDesc( account);
}
 
}

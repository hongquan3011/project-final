package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import duan.edu.dao.CartDAO;
import duan.edu.entity.Cart;
import duan.edu.service.CartService;
@Service
public class CartServiceImpl implements CartService {
@Autowired
CartDAO dao;
	@Override
	public List<Cart> findByUsername(String username) {
		// TODO Auto-generated method stub
		return dao.findbyUsername(username);
	}
	@Override
	public List<Cart> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}
	@Override
	public void delete(Integer id) {
		 dao.deleteById(id);;
		
	}
	@Override
	public Cart update(Cart cart) {
		// TODO Auto-generated method stub
		return dao.save(cart);
	}
	@Override
	public Cart create(Cart cart) {
		// TODO Auto-generated method stub
		return dao.save(cart);
	}
	@Override
	public void deleteUser(String user) {
		 dao.deleteUser(user);;
		
	}
 
}

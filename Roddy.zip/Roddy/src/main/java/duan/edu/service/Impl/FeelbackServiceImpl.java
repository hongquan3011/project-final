package duan.edu.service.Impl;
 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.FeelbackDAO;

import duan.edu.entity.Feelback;

import duan.edu.service.FeelbackService; 
@Service
public class FeelbackServiceImpl implements FeelbackService {
@Autowired
FeelbackDAO dao;



@Override
public List<Feelback> findAll() {
	return dao.findAll();
}

@Override
public Feelback findById(Integer id) {
	return dao.findById(id).get();
}





@Override
public Feelback update(Feelback Feelback) {
	return dao.save(Feelback);
}


@Override
public Feelback create(Feelback feelback) {
	// TODO Auto-generated method stub
	return dao.save(feelback);
}

@Override
public List<Feelback> findByProductId(String id) {
	// TODO Auto-generated method stub
	return dao.findByProductId(id);
}


}

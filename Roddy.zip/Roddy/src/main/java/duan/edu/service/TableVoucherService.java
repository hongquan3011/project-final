package duan.edu.service;

import java.util.List;

import duan.edu.entity.TableVoucher;

public interface TableVoucherService {

	List<TableVoucher> findByOrderId(Integer id);

}

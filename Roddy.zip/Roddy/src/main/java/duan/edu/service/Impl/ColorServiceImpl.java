package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.ColorDAO;
import duan.edu.service.ColorService;

import duan.edu.entity.*;
@Service
public class ColorServiceImpl implements ColorService {
@Autowired
ColorDAO dao;

@Override
public List<Color> findAll() {
	return dao.findAll();
}

@Override
public Color findById(Integer id) {
	return dao.findById(id).get();
}



@Override
public Color create(Color Color) {
	return dao.save(Color);
}

@Override
public Color update(Color Color) {
	return dao.save(Color);
}

@Override
public List<Color> findbyProduct(String id) {
	 
	return dao.findbyProduct(id);
}
  
}

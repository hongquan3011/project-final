package duan.edu.service.Impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import duan.edu.dao.ImageDAO;
import duan.edu.entity.Image;
import duan.edu.entity.Product;

import duan.edu.service.ImageService; 
 
@Service
public class ImageServiceImpl implements ImageService {
@Autowired
ImageDAO dao;
@Override
public List<Image> findbyProduct(String id) {
	// TODO Auto-generated method stub
	return dao.findbyProduct(id);
}
@Override
public void delete(Integer id) {
	dao.deleteById(id);
}
@Override
public List<Image> findAll() { 
	return  dao.findAll();
}
@Override
public List<Image> create(JsonNode imgData) {
	ObjectMapper mapper = new ObjectMapper(); 
	
	TypeReference<List<Image>> img = new TypeReference <List<Image>>() {}; 
	List<Image> image = mapper.convertValue(imgData.get("image"), img); 
	 
	return   dao.saveAll(image);
}
public Image update(Image img) {
	// TODO Auto-generated method stub
	return dao.save(img);
}
@Override
public Image findbyProductIdAndName(String id, String name) {
	 
	return dao.findbyProductIdAndName(id, name);
}
@Override
public Image findById(Integer id) {
	 
	return dao.findById(id).get();
}
 
}

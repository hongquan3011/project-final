package duan.edu.service;

import java.util.List;

public interface ReportService {
//List<Object[]> cateReport();
}

package duan.edu.service.Impl;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.hibernate.query.criteria.internal.compile.CriteriaQueryTypeQueryAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import duan.edu.entity.Category;
import duan.edu.entity.Product;
import duan.edu.respository.ReportRespository;
import duan.edu.service.ReportService;

@Service
public class ReportServiceImpl implements ReportService {
//	@Autowired
//	private ReportRespository respository;
//
//	@Override
//	public List<Object[]> cateReport() {
//		return this.respository.cateReport();
//	}

}

package duan.edu.service;

import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Account;
import duan.edu.entity.Order;
import duan.edu.entity.OrderDetail;

public interface OrderService {
	List<Order> findbyUsername(String username);

	Order findById(Integer id);
	
	Order create(JsonNode orderData);

	Order save(Order order);

	List<Order> findByStatusAndUsername(String id, String username);
	Long count(String user);

	List<Order> findAll();

	List<Order> findByStatus(String status);

	List<Order> findAllDesc();

	List<Order> findTop10ByUsername(Account aCC);

	

 
}

package duan.edu.service;

import java.util.List;

import duan.edu.entity.ImportInvoices;

public interface ImportInvoicesService {
	
	ImportInvoices findById(Integer id);

	List<ImportInvoices> findAll();
	
	ImportInvoices create(ImportInvoices product);
	 


	ImportInvoices update(ImportInvoices imp);
}

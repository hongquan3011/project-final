package duan.edu.service;

import java.util.List;

import duan.edu.entity.ColorSize; 

public interface ColorSizeService {
	List<ColorSize> findbyProduct(String id);

	void   delete(Integer id);

	List<ColorSize> findAll();

	ColorSize create(ColorSize tbl );

	ColorSize update(ColorSize tbl ); 
	 ColorSize findById(Integer id);

}

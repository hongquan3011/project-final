package duan.edu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.OrderDetailDAO;
import duan.edu.entity.Order;
import duan.edu.entity.OrderDetail;
import duan.edu.service.OrderDetailService; 
@Service
public class OrderDetailServiceImpl implements OrderDetailService {
@Autowired
OrderDetailDAO dao;

@Override
public List<OrderDetail> findByOrderId(Integer id) {
	 
	return dao.findByOrderId(id);
}

 
 
}

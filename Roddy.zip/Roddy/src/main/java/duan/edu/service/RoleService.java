package duan.edu.service;

import java.util.List;

import duan.edu.entity.Role;



public interface RoleService {

	public List<Role> findAll();

}

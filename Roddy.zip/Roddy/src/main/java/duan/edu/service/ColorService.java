package duan.edu.service;

import java.util.List;

import duan.edu.entity.Color;

public interface ColorService {

	Color findById(Integer id);

	List<Color> findAll();

	Color create(Color product);
 
	List<Color> findbyProduct(String id);

	Color update(Color Color);


}

package duan.edu.service;

import java.util.List;


import duan.edu.entity.Size;

public interface SizeService {
	
	Size findById(Integer id);
	List<Size> findAll();

	Size create(Size product);

	Size update(Size product);
 

}

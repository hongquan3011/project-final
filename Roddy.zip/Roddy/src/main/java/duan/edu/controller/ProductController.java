package duan.edu.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import duan.edu.dao.FeelbackDAO;
import duan.edu.dao.ProductDAO;
import duan.edu.entity.Feelback;
import duan.edu.entity.Product;
import duan.edu.service.FeelbackService;
import duan.edu.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	@Autowired
	ProductDAO dao;
	@Autowired
	FeelbackService feelbackService;
	@RequestMapping("/product/detail/{id}")
	public String detail(Model model, @PathVariable("id") String id) {
		Product pro = productService.findById(id);
		List<Feelback> fb = feelbackService.findByProductId(id);
		model.addAttribute("product",pro);
		model.addAttribute("feelbacks",fb);
		return "product/productdetail";
	}

	
	@RequestMapping("/product/{name}")
	public String list(@PathVariable("name") String name,   Model model,@RequestParam("bid") Optional<String> bid,@RequestParam("sort") Optional<String> sort,
			@RequestParam("cid") Optional<String> cid ,@RequestParam("p") Optional<Integer> p
		    ) {

		 Pageable pageable = PageRequest.of(p.orElse(1) - 1, 12);
		if (bid.isPresent()) {
			Page<Product> list = productService.findByBrand(bid.get(),true,pageable);
			model.addAttribute("product",list);
		
		}else if(cid.isPresent()){ 
			Page<Product> list = productService.findByCategory(cid.get(), true,pageable);
			model.addAttribute("product",list);
		}else if(name.equals("list"))  { 
			 Page<Product> list = productService.findAllByStatus(pageable); 
			model.addAttribute("product",list);
		}else  if (bid.isPresent()) {
			Page<Product> list = productService.findByBrand(bid.get(),true,pageable);
			model.addAttribute("product",list);
		
		}
		else {  
				Page<Product> list =  productService.findBySection(name,pageable);		 
				 model.addAttribute("product",list);
		}
		
		
		return "product/product";
	}
	@RequestMapping("/product/list/search")
	public String search(Model model, @RequestParam("search") String search) {
		if (search == null) {
			 Pageable pageable = PageRequest.of(0, 12);
			model.addAttribute("product", productService.findAllByStatus(pageable));
		} else {
			 Pageable pageable = PageRequest.of(0, 12);
			Page<Product> items = productService.findByNameContainingAndStatus(search,pageable);
			model.addAttribute("product", items);
			model.addAttribute("search", search);
		}
		return "product/product";
	}
 
	@RequestMapping("/product/sort")
	public String sort(Model model,@RequestParam("field") Optional<String> field) {
		
		Sort sort = Sort.by(Direction.DESC, field.orElse("price"));
		model.addAttribute("field", field.orElse("price").toUpperCase());
		List<Product> items = (List<Product>) dao.findAll(sort);
		model.addAttribute("product", items);
		return "product/product";
		}
}

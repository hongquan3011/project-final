package duan.edu.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import duan.edu.entity.Account;
import duan.edu.service.AccountService;
@Controller
public class ProfileController {
	@Autowired
	AccountService accountService;
	@RequestMapping("profile")
	public String profile(Model model,HttpServletRequest request) {
		String username = request.getRemoteUser();
		Account acc = accountService.findById(username);
		model.addAttribute("account", acc);
		return "security/profile";
	}
	@PostMapping("profile/update")
	public String save(Model model, @ModelAttribute("account") Account account) {
		account.setCreateday(new Date());
		accountService.save(account);
		System.out.println("ok"+account.getFullname());
	return "redirect:/security/profile";
	}
}

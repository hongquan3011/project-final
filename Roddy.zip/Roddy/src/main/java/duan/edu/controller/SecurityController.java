package duan.edu.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import duan.edu.entity.Account;
import duan.edu.service.AccountService;

@Controller
public class SecurityController {
	@Autowired
	AccountService accountservice;
	
	@PostMapping("/security/register")
	public String saveOrUpdate(@RequestBody  Model model,@Valid @ModelAttribute("account") Account account,Errors errors) throws ServletException {
	
	List<Account> list = accountservice.findAll();
	int i = 0 ;
	for (Account acc : list) {
		if (account.getUsername().equals(acc.getUsername())) {				
				i =1;
		}
	}

         if (i==1) {
			model.addAttribute("messagee", "Tên tài khoản đã tồn tại");
		
		}else {
	
account.setMemberpoint(0);
	account.setUsedpoint(0);
	account.setStatus(true);
		account.setCreateday(new Date());
		accountservice.save(account);
		System.out.println("thành công"+account.getUsername());
		model.addAttribute("messagee", "Đăng ký thành công");	}

		
		return "security/login";
	}
	@RequestMapping("/security/login/form")
	public String loginForm(Model model) {
		Account a = new Account();
		model.addAttribute("account", a);
		model.addAttribute("message", "Vui lòng đăng nhập!");
		return "security/login";
	}
	
	@RequestMapping("/security/login/success")
	public String loginSuccess(Model model) {
		model.addAttribute("message", "Đăng nhập thành công!");
		return "redirect:/";
	}
	
	@RequestMapping("/security/login/error")
	public String loginError(Model model) {
		Account a = new Account();
		model.addAttribute("account", a);
		model.addAttribute("message", "Tài khoản hoặc mật khẩu sai!");
		return "security/login";
	}
	
	@RequestMapping("/security/login/unauthoried")
	public String unauthoried(Model model) {
		model.addAttribute("message", "Không có quyền!");
		return "security/login";
	}
	
	@RequestMapping("/security/logoff/success")
	public String logoffSuccess(Model model) {
		model.addAttribute("message", "Đăng xuất thành công!");
		return "redirect:/";
	}
}

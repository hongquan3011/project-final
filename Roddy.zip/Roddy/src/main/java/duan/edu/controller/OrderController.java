package duan.edu.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import duan.edu.entity.Order;
import duan.edu.entity.OrderDetail;
import duan.edu.entity.TableVoucher;
import duan.edu.entity.Voucher;
import duan.edu.service.OrderDetailService;
import duan.edu.service.OrderService;
import duan.edu.service.TableVoucherService;
import duan.edu.service.VoucherService;

@Controller
public class OrderController {
	@Autowired
	OrderService orderService;
	@Autowired
	OrderDetailService orderDetailService;
	@Autowired
	TableVoucherService voucherService;
@RequestMapping("/order/list")
public String myorder(Model model,HttpServletRequest request) {
	String username = request.getRemoteUser();
	model.addAttribute("orders", orderService.findbyUsername(username));
	return "order/myorder";
}
@RequestMapping("/order/detail/{id}")
public String detail(@PathVariable("id")Integer id, Model model) {
	model.addAttribute("order", orderService.findById(id));
	List<OrderDetail> detail=orderDetailService.findByOrderId(id);
	List<TableVoucher>  voucher =voucherService.findByOrderId(id);
	float price=0;
	float voucherp=0;
	for (OrderDetail orderDetail : detail) {
		price=  price+ orderDetail.getPrice()*orderDetail.getAmount() ;
	}
	System.out.println(price);
	if(voucher.size()!=0) {
		for (TableVoucher v : voucher) {
			voucherp= (float) (voucherp+ v.getVoucher().getValue()) ;
		}
	}  
	model.addAttribute("price", price-voucherp); 
	model.addAttribute("priceAff", price); 
	model.addAttribute("voucher", voucherp); 
	return "order/orderdetail";
}
@RequestMapping("/order/checkout")
public String checkout() {
	return "order/checkout";
}
@GetMapping("/order/list/{id}")
public String getStatus(@PathVariable("id") String  id,HttpServletRequest request,Model model) {   
	 String username = request.getRemoteUser();
	 model.addAttribute("orders",orderService.findByStatusAndUsername(id,username));
	 return "order/order";
} 
}

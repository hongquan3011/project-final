package duan.edu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import duan.edu.entity.Brand;
import duan.edu.entity.Category;
import duan.edu.entity.Product;
import duan.edu.service.BrandService;
import duan.edu.service.CategoryService;
import duan.edu.service.ProductService;

@Controller
public class HomeController {
	@Autowired
	ProductService productService;
	@Autowired
	BrandService brandService;
	@RequestMapping({"/", "/home"})
	public String home( Model model) { 
		List<Product>  product=productService.findTop4ByCategorySectionAndStatusOrderByCreateDayDesc("aoquan",true); 
		model.addAttribute("top",product);
		List<Product>  product2=productService.findTop4ByCategorySectionAndStatusOrderByCreateDayDesc("tuixach",true); 
		model.addAttribute("top2",product2);
		List<Product>  phukien=productService.findAllByCategorySectionAndStatusOrderByCreateDayDesc("phukien",true); 
		model.addAttribute("phukien",phukien);
		List<Brand>  cate=brandService.findAllByStatus(); 
		model.addAttribute("thuonghieu",cate);
		return "layout/home";
	}
	@RequestMapping({"/admin","/admin/home"})
	public String admin() {
		return "redirect:/assets/admin/index.html";
	}
	@RequestMapping({"/about"})
	public String about() {
		return "layout/about";
	}
	@RequestMapping({"/contact"})
	public String contact() {
		return "layout/contact";
	}
	@RequestMapping({"/blog"})
	public String blog() {
		return "layout/blog";
	}
}

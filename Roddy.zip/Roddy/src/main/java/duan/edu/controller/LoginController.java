package duan.edu.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import duan.edu.entity.Account;
import duan.edu.service.AccountService;

@Controller
public class LoginController {
	@Autowired
	AccountService accountservice;

//	@RequestMapping("login")
//	public String login(ModelMap model) {	
//		model.addAttribute("ACTION", "register");
//		return "security/login.html";
//	}
//	@PostMapping("/checklogin")
//	public String checklogin(ModelMap model, @RequestParam("username") String username,
//			@RequestParam("password") String password, HttpSession session , HttpServletRequest httpServletRequest) {
//
//		if (accountservice.checkLogin(username, password)) {
//			System.out.println("Login Success");
//			return "redirect:/";
//		} else {
//			System.out.println("Login Faild");
//			model.addAttribute("ERROR", "Incorrect account or password");
//		}
//		return "login";
//	}
//	@GetMapping("/logout")
//	public String logout(HttpSession session) {
//		session.removeAttribute("USERNAME");
//		return "redirect:/login";
//	}
//	@PostMapping("/register")
//	public String saveOrUpdate(ModelMap model, @ModelAttribute("account") Account account, HttpServletRequest request) throws ServletException {
//		String password = account.getPassword();
//		accountservice.save(account);
//		System.out.println("Login Success");
//		return "redirect:/login";
//	}
//	@GetMapping("profile")
//	public String profile(ModelMap model) {
//		
//		return "security/profile.html";
//	}
}

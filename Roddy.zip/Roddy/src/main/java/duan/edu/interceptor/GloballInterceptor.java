package duan.edu.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import duan.edu.service.BrandService;
import duan.edu.service.CategoryService;



@Component
public class GloballInterceptor implements HandlerInterceptor{
	@Autowired
	CategoryService categoryService;
	@Autowired
	BrandService brandService;
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		request.setAttribute("cates", categoryService.findAllByStatus());
		request.setAttribute("brand", brandService.findAllByStatus());
	}
	
}

package duan.edu.dao; 

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Category;
import duan.edu.entity.Product;
 
 
 
public interface ProductDAO extends JpaRepository<Product, String>{ 
	@Query("SELECT p FROM Product p WHERE CONCAT(p.name, p.brand.name, p.category.name) LIKE %?1%  and p.status=1")
	Page<Product> findByNameContainingAndStatus(String search,Pageable pageable);
	//@Query("SELECT p FROM Product p WHERE p.brand.id=?1")
	Page<Product> findByBrandIdAndStatus(String bid,Boolean status,Pageable pageable);
	Page<Product> findByCategoryIdAndStatus(String cid, Boolean status,Pageable pageable);
	@Query("SELECT p FROM Product p where p.status=1 ")
	Page<Product> findAllByStatus(Pageable pageable);
	@Query("SELECT p FROM Product p Order By p.status Desc")
	List<Product> findAllDesc();
	@Query("SELECT p FROM Product p where p.category.section=?1 and p.status=1")
	Page<Product> findBySection(String section,Pageable pageable);	
	Product save(JsonNode product);   
	List<Product> findTop4ByCategorySectionAndStatusOrderByCreateDayDesc(String string, boolean b);
	List<Product> findAllByCategorySectionAndStatusOrderByCreateDayDesc(String string, boolean b);
 
	}


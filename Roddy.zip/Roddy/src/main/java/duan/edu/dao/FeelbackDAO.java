package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import duan.edu.entity.Feelback; 
 
public interface FeelbackDAO extends JpaRepository<Feelback, Integer>{
	@Query("SELECT f FROM Feelback f WHERE f.product.id=?1")
	List<Feelback> findByProductId(String id);
	}


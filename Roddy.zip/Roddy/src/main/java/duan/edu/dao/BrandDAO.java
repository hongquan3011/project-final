package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import duan.edu.entity.Brand;
 
 
public interface BrandDAO extends JpaRepository<Brand, String>{ 
	@Query("SELECT b FROM Brand b Order By b.status Desc")
	List<Brand> findAllDesc(); 
	@Query("SELECT b FROM Brand b where b.status=1 ")
	List<Brand> findAllByStatus(); 
	}


package duan.edu.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import duan.edu.entity.Cart;


public interface CartDAO extends JpaRepository<Cart, Integer>{
	 @Query("select o from Cart o where o.account.username = ?1")
	 List<Cart> findbyUsername(String username);
	 @Transactional
	 @Modifying
	 @Query("delete   from Cart o  where  o.account.username =:#{#user}")
	void deleteUser(@Param("user") String user);

 
}

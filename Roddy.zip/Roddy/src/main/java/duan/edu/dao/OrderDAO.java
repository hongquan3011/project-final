package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import duan.edu.entity.Account;
import duan.edu.entity.Order; 
 
 @Repository
public interface OrderDAO extends JpaRepository<Order, Integer>{ 
	 @Query("select o from Order o where o.account.username = ?1 Order By  o.id Desc ")
	 List<Order> findbyUsername(String username);
	 @Query("select o from Order o where o.status=?1 and o.account.username = ?2 Order By o.id Desc")
	List<Order> findByStatusAndUsername(String id, String username);
	 
	 List<Order> findByStatusOrderByOrderdayDesc(String status);
	 @Query("select o from Order o Order By o.orderday Desc ") 
	List<Order> findAllDesc();
	  
	List<Order> findTop10ByAccountOrderByOrderdayDesc(Account acc);
	 
	}


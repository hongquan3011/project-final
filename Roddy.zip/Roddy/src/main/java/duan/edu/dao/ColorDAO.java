package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import duan.edu.entity.Color; 
 
 
public interface ColorDAO extends JpaRepository<Color, Integer>{
	@Query("Select c from  Color c join ColorSize t on c.id=t.color.id where t.product.id =?1")
	List<Color> findbyProduct(String id);

	}


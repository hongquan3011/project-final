package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Image; 
 
 
public interface ImageDAO extends JpaRepository<Image, Integer>{ 
	@Query("select c from Image c where c.product.id =?1")
	List<Image> findbyProduct(String id);

	Image save(JsonNode img);
	@Query("select c from Image c where c.product.id =?1  and c.name=?2")
	Image findbyProductIdAndName(String id, String name);
 
	}


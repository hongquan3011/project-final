package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import duan.edu.entity.TableVoucher; 
 
 
public interface TableVoucherDao extends JpaRepository<TableVoucher, Integer>{
	 @Query("select v from  TableVoucher v where v.order.id=?1 ")
	List<TableVoucher> findByOrderId(Integer id);
 
	}


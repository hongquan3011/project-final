package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import duan.edu.entity.Account;
import duan.edu.entity.Voucher; 
 
public interface VoucherDAO extends JpaRepository<Voucher, Integer>{
     @Query("select v from  Voucher v where v.vouchercode=?1 ")
	Voucher findByVouchercode(String id);

	List<Voucher> findByAccountOrderByExpireddayDesc(Account account);

 
	}


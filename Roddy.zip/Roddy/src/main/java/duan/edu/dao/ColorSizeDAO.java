package duan.edu.dao; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import duan.edu.entity.ColorSize; 
public interface ColorSizeDAO extends JpaRepository<ColorSize, Integer>{
    @Query("select p from ColorSize p where p.product.id=?1")
	List<ColorSize> findbyProduct(String id);
    }

